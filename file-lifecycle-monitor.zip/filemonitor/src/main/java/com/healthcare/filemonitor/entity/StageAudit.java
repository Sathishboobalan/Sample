package com.healthcare.filemonitor.entity;

import com.healthcare.filemonitor.entity.enums.StageStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.Duration;
import java.time.LocalDateTime;

@Entity
@Table(name = "STAGE_AUDIT")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StageAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "stage_audit_id")
    private Long stageAuditId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_audit_id", nullable = false)
    private FileAudit fileAudit;

    @Column(name = "stage_name", length = 50)
    private String stageName;

    @Enumerated(EnumType.STRING)
    @Column(name = "stage_status", length = 20)
    private StageStatus stageStatus;

    @Column(name = "entry_datetime")
    private LocalDateTime entryDatetime;

    @Column(name = "exit_datetime")
    private LocalDateTime exitDatetime;

    @Column(name = "record_count_at_stage")
    private Integer recordCountAtStage;

    @Column(name = "error_message", length = 500)
    private String errorMessage;

    @Column(name = "created_date")
    @Builder.Default
    private LocalDateTime createdDate = LocalDateTime.now();

    @Transient
    public Long getDurationSeconds() {
        if (entryDatetime == null || exitDatetime == null) return null;
        return Duration.between(entryDatetime, exitDatetime).getSeconds();
    }
}
