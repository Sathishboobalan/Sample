package com.healthcare.filemonitor.entity;

import com.healthcare.filemonitor.entity.enums.AlertType;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "ALERT_LOG")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AlertLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "alert_id")
    private Long alertId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_config_id", nullable = false)
    private FileConfig fileConfig;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_audit_id")
    private FileAudit fileAudit; // nullable - file may be MISSING, no audit row yet

    @Enumerated(EnumType.STRING)
    @Column(name = "alert_type", length = 30)
    private AlertType alertType;

    @Column(name = "alert_message", length = 500)
    private String alertMessage;

    @Column(name = "alert_datetime")
    @Builder.Default
    private LocalDateTime alertDatetime = LocalDateTime.now();

    @Column(name = "resolved_flag", length = 1)
    @Builder.Default
    private String resolvedFlag = "N";

    @Column(name = "resolved_datetime")
    private LocalDateTime resolvedDatetime;
}
