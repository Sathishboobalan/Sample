package com.healthcare.filemonitor.entity.enums;

public enum StageStatus {
    STARTED,
    COMPLETED,
    FAILED,
    SKIPPED
}
