package com.healthcare.filemonitor.repository;

import com.healthcare.filemonitor.entity.StageConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StageConfigRepository extends JpaRepository<StageConfig, Long> {
    List<StageConfig> findByFileConfig_FileConfigIdOrderByStageSequenceAsc(Long fileConfigId);
}
