package com.healthcare.filemonitor.controller;

import com.healthcare.filemonitor.entity.FileAudit;
import com.healthcare.filemonitor.entity.FileConfig;
import com.healthcare.filemonitor.entity.StageAudit;
import com.healthcare.filemonitor.exception.StorageProviderNotFoundException;
import com.healthcare.filemonitor.repository.FileAuditRepository;
import com.healthcare.filemonitor.repository.StageAuditRepository;
import com.healthcare.filemonitor.scheduler.FileMonitorScheduler;
import com.healthcare.filemonitor.service.FileMonitoringService;
import com.healthcare.filemonitor.service.RouteCacheService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/monitor")
@RequiredArgsConstructor
public class MonitorController {

    private final RouteCacheService routeCacheService;
    private final FileMonitoringService fileMonitoringService;
    private final FileMonitorScheduler scheduler;
    private final FileAuditRepository fileAuditRepository;
    private final StageAuditRepository stageAuditRepository;

    /** Force-refresh the in-memory route cache after a config change in the DB. */
    @PostMapping("/cache/refresh")
    public ResponseEntity<Map<String, Object>> refreshCache() {
        routeCacheService.refresh();
        return ResponseEntity.ok(Map.of(
                "status", "REFRESHED",
                "activeConfigCount", routeCacheService.size(),
                "timestamp", LocalDateTime.now()
        ));
    }

    @GetMapping("/cache/status")
    public ResponseEntity<Map<String, Object>> cacheStatus() {
        return ResponseEntity.ok(Map.of(
                "activeConfigCount", routeCacheService.size(),
                "lastRefreshed", String.valueOf(routeCacheService.getLastRefreshed()),
                "scanInProgress", scheduler.isScanInProgress()
        ));
    }

    /** Manually trigger a scan for every active config right now (does not wait for the schedule). */
    @PostMapping("/scan/trigger")
    public ResponseEntity<Map<String, Object>> triggerScanAll() {
        List<FileConfig> configs = routeCacheService.getAllActiveConfigs();
        fileMonitoringService.scanAll(configs);
        return ResponseEntity.ok(Map.of(
                "status", "SCAN_COMPLETED",
                "configsScanned", configs.size(),
                "timestamp", LocalDateTime.now()
        ));
    }

    /** Manually trigger a scan for one specific interface (useful for testing a single client). */
    @PostMapping("/scan/trigger/{fileConfigId}")
    public ResponseEntity<Map<String, Object>> triggerScanOne(@PathVariable Long fileConfigId) {
        FileConfig fc = routeCacheService.getById(fileConfigId);
        if (fc == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "No active FileConfig found for id " + fileConfigId));
        }
        try {
            fileMonitoringService.scan(fc);
        } catch (StorageProviderNotFoundException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
        return ResponseEntity.ok(Map.of(
                "status", "SCAN_COMPLETED",
                "fileConfigId", fileConfigId,
                "timestamp", LocalDateTime.now()
        ));
    }

    /** Full stage-by-stage audit trail for one tracked file. */
    @GetMapping("/audit/{fileAuditId}")
    public ResponseEntity<Map<String, Object>> getAuditTrail(@PathVariable Long fileAuditId) {
        FileAudit audit = fileAuditRepository.findById(fileAuditId)
                .orElse(null);
        if (audit == null) {
            return ResponseEntity.notFound().build();
        }
        List<StageAudit> stages = stageAuditRepository
                .findByFileAudit_FileAuditIdOrderByEntryDatetimeAsc(fileAuditId);

        return ResponseEntity.ok(Map.of(
                "fileAuditId", audit.getFileAuditId(),
                "fileName", audit.getActualFileName(),
                "status", audit.getStatus(),
                "overallResult", audit.getOverallResult(),
                "receivedDatetime", String.valueOf(audit.getReceivedDatetime()),
                "stages", stages
        ));
    }
}
