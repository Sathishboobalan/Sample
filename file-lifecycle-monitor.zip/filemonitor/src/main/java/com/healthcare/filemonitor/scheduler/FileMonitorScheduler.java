package com.healthcare.filemonitor.scheduler;

import com.healthcare.filemonitor.entity.FileConfig;
import com.healthcare.filemonitor.service.FileMonitoringService;
import com.healthcare.filemonitor.service.RouteCacheService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Periodically triggers a monitoring pass across every active FileConfig
 * (LOCAL + FSX + S3 alike - the correct StorageProvider is resolved per-config).
 *
 * fixedDelay (not fixedRate) is used deliberately: it waits for one full
 * scan cycle to finish before starting the next, avoiding overlapping runs
 * if a network filesystem (FSX) or S3 call is slow.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class FileMonitorScheduler {

    private final RouteCacheService routeCacheService;
    private final FileMonitoringService fileMonitoringService;

    // guards against a scheduled run overlapping with a manually-triggered run
    private final AtomicBoolean scanInProgress = new AtomicBoolean(false);

    @Scheduled(fixedDelayString = "${filemonitor.scan.fixed-delay-millis:60000}",
               initialDelayString = "${filemonitor.scan.initial-delay-millis:10000}")
    public void runScheduledScan() {
        if (!scanInProgress.compareAndSet(false, true)) {
            log.warn("Previous scan still in progress - skipping this cycle");
            return;
        }
        try {
            List<FileConfig> activeConfigs = routeCacheService.getAllActiveConfigs();
            log.info("Starting scan cycle - {} active file configs", activeConfigs.size());
            long start = System.currentTimeMillis();

            fileMonitoringService.scanAll(activeConfigs);

            log.info("Scan cycle completed in {} ms", System.currentTimeMillis() - start);
        } catch (Exception e) {
            log.error("Scheduled scan cycle failed: {}", e.getMessage(), e);
        } finally {
            scanInProgress.set(false);
        }
    }

    public boolean isScanInProgress() {
        return scanInProgress.get();
    }
}
