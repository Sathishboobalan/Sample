package com.healthcare.filemonitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Entry point for the File Lifecycle Monitoring System.
 *
 * Supports monitoring files across three storage backends:
 *  - LOCAL   : plain filesystem paths (dev/local testing)
 *  - FSX     : AWS FSx volumes mounted as NFS/SMB paths on the host (behaves like a filesystem)
 *  - S3      : AWS S3 buckets, accessed via AWS SDK v2
 *
 * The active storage backend per FILE_CONFIG row is data-driven (storage_type column),
 * so a single running instance can simultaneously monitor Local + FSX + S3 sources,
 * selecting the correct StorageProvider at runtime via StorageProviderFactory.
 */
@SpringBootApplication
@EnableScheduling
@EnableAsync
public class FileMonitorApplication {

    public static void main(String[] args) {
        SpringApplication.run(FileMonitorApplication.class, args);
    }
}
