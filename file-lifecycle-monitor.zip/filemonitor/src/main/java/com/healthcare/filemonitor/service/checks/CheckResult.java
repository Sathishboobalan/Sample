package com.healthcare.filemonitor.service.checks;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CheckResult {
    private boolean passed;
    private String message;
    private Integer recordCount; // populated by RECORD_COUNT_MATCH check, null otherwise

    public static CheckResult pass(String message) {
        return CheckResult.builder().passed(true).message(message).build();
    }

    public static CheckResult fail(String message) {
        return CheckResult.builder().passed(false).message(message).build();
    }
}
