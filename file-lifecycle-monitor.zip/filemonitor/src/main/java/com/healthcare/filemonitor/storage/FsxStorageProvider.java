package com.healthcare.filemonitor.storage;

import com.healthcare.filemonitor.entity.enums.StorageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Monitors AWS FSx volumes (FSx for Windows File Server / FSx for NetApp ONTAP / FSx for Lustre).
 *
 * FSx is mounted by the OS as an NFS or SMB path (e.g. /mnt/fsx/ibx-inbound), so from Java's
 * standpoint it is accessed identically to a local filesystem path via java.nio.file.
 *
 * The reason this is a SEPARATE provider from LocalStorageProvider (rather than reusing it)
 * is that network-mounted storage is prone to transient I/O errors (mount hiccups, latency
 * spikes, momentary unavailability), so this provider adds retry-with-backoff around reads.
 */
@Slf4j
@Component
public class FsxStorageProvider implements StorageProvider {

    @Value("${filemonitor.fsx.retry.max-attempts:3}")
    private int maxAttempts;

    @Value("${filemonitor.fsx.retry.backoff-millis:500}")
    private long backoffMillis;

    @Override
    public StorageType getStorageType() {
        return StorageType.FSX;
    }

    @Override
    public List<FileMetadata> listFiles(String location, String prefixOrNull, String fileNameRegex) {
        List<FileMetadata> results = new ArrayList<>();

        Path dir = Paths.get(location);
        Pattern pattern = (fileNameRegex == null || fileNameRegex.isBlank())
                ? null
                : Pattern.compile(fileNameRegex);

        withRetry(() -> {
            if (!Files.isDirectory(dir)) {
                log.warn("FSX path does not exist or mount is unavailable: {}", location);
                return null;
            }
            try (Stream<Path> stream = Files.list(dir)) {
                stream.filter(Files::isRegularFile)
                      .forEach(path -> {
                          String fileName = path.getFileName().toString();
                          if (pattern == null || pattern.matcher(fileName).matches()) {
                              results.add(toMetadata(path));
                          }
                      });
            }
            return null;
        }, "listFiles:" + location);

        return results;
    }

    @Override
    public Optional<FileMetadata> getFileMetadata(String location, String prefixOrNull, String fileName) {
        Path path = Paths.get(location, fileName);
        Boolean exists = withRetry(() -> Files.exists(path), "exists:" + path);
        if (exists == null || !exists) {
            return Optional.empty();
        }
        return Optional.of(toMetadata(path));
    }

    @Override
    public boolean exists(String location, String prefixOrNull, String fileName) {
        Path path = Paths.get(location, fileName);
        Boolean result = withRetry(() -> Files.exists(path), "exists:" + path);
        return result != null && result;
    }

    @Override
    public long countRecords(String location, String prefixOrNull, String fileName) {
        Path path = Paths.get(location, fileName);
        Long count = withRetry(() -> {
            if (!Files.exists(path)) return -1L;
            try (BufferedReader reader = Files.newBufferedReader(path)) {
                return reader.lines().count();
            }
        }, "countRecords:" + path);
        return count != null ? count : -1L;
    }

    @Override
    public boolean isAvailable(String location) {
        Boolean result = withRetry(() -> Files.isDirectory(Paths.get(location)), "isAvailable:" + location);
        return result != null && result;
    }

    private FileMetadata toMetadata(Path path) {
        try {
            BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class);
            return FileMetadata.builder()
                    .fileName(path.getFileName().toString())
                    .fullPath(path.toAbsolutePath().toString())
                    .sizeInBytes(attrs.size())
                    .lastModified(Instant.ofEpochMilli(attrs.lastModifiedTime().toMillis()))
                    .build();
        } catch (IOException e) {
            log.error("Failed reading FSX attributes for {}: {}", path, e.getMessage());
            return FileMetadata.builder()
                    .fileName(path.getFileName().toString())
                    .fullPath(path.toAbsolutePath().toString())
                    .sizeInBytes(0)
                    .lastModified(Instant.EPOCH)
                    .build();
        }
    }

    /**
     * Generic retry-with-backoff wrapper for network-filesystem operations.
     * Swallows IOException between attempts and logs; returns null if all attempts fail.
     */
    private <T> T withRetry(IoSupplier<T> action, String opDescription) {
        int attempt = 0;
        while (attempt < maxAttempts) {
            attempt++;
            try {
                return action.get();
            } catch (IOException e) {
                log.warn("FSX operation [{}] failed on attempt {}/{}: {}",
                        opDescription, attempt, maxAttempts, e.getMessage());
                if (attempt >= maxAttempts) {
                    log.error("FSX operation [{}] failed after {} attempts", opDescription, maxAttempts, e);
                    return null;
                }
                try {
                    Thread.sleep(backoffMillis * attempt); // linear backoff
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    return null;
                }
            }
        }
        return null;
    }

    @FunctionalInterface
    private interface IoSupplier<T> {
        T get() throws IOException;
    }
}
