package com.healthcare.filemonitor.service;

import com.healthcare.filemonitor.entity.*;
import com.healthcare.filemonitor.entity.enums.*;
import com.healthcare.filemonitor.repository.FileAuditRepository;
import com.healthcare.filemonitor.repository.StageAuditRepository;
import com.healthcare.filemonitor.service.checks.CheckResult;
import com.healthcare.filemonitor.service.checks.CheckStrategyFactory;
import com.healthcare.filemonitor.service.checks.FileCheckStrategy;
import com.healthcare.filemonitor.storage.FileMetadata;
import com.healthcare.filemonitor.storage.StorageProvider;
import com.healthcare.filemonitor.storage.StorageProviderFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

/**
 * Core orchestration service. For each active FileConfig:
 *   1. Resolves the StorageProvider (LOCAL / FSX / S3) via StorageProviderFactory
 *   2. Lists files at the first configured stage's location
 *   3. Creates/updates FILE_AUDIT for each file found
 *   4. Walks the file forward through STAGE_CONFIG in sequence, running the
 *      configured CheckType at each stage and recording STAGE_AUDIT rows
 *   5. Flags files that never arrived within their expected window as MISSING
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FileMonitoringService {

    private final StorageProviderFactory storageProviderFactory;
    private final CheckStrategyFactory checkStrategyFactory;
    private final FileAuditRepository fileAuditRepository;
    private final StageAuditRepository stageAuditRepository;
    private final AlertService alertService;

    /**
     * Entry point invoked by the scheduler (or manually via REST) for a single FileConfig.
     */
    @Transactional
    public void scan(FileConfig fileConfig) {
        if (fileConfig.getStages().isEmpty()) {
            log.warn("FileConfig id={} ({}/{}) has no stages configured - skipping",
                    fileConfig.getFileConfigId(), fileConfig.getClientName(), fileConfig.getInterfaceName());
            return;
        }

        StorageProvider provider = storageProviderFactory.getProvider(fileConfig.getStorageType());
        StageConfig firstStage = fileConfig.getStages().get(0);

        String location = resolveLocation(fileConfig, firstStage);
        String prefix = resolvePrefix(fileConfig, firstStage);

        List<FileMetadata> filesAtEntry = provider.listFiles(location, prefix, fileConfig.getFileNameRegex());

        if (filesAtEntry.isEmpty()) {
            log.debug("No files currently at entry stage for {}/{} at {}",
                    fileConfig.getClientName(), fileConfig.getInterfaceName(), location);
        }

        for (FileMetadata meta : filesAtEntry) {
            FileAudit fileAudit = fileAuditRepository
                    .findByFileConfig_FileConfigIdAndActualFileName(fileConfig.getFileConfigId(), meta.getFileName())
                    .orElseGet(() -> createNewFileAudit(fileConfig, meta));

            if (fileAudit.getStatus() == FileStatus.COMPLETED || fileAudit.getStatus() == FileStatus.FAILED) {
                continue; // terminal state already reached, nothing more to process for this file
            }

            processStages(provider, fileConfig, fileAudit);
        }

        checkForMissingFiles(fileConfig);
    }

    /** Convenience overload used by the scheduler to run every active config in one pass. */
    public void scanAll(List<FileConfig> activeConfigs) {
        for (FileConfig fc : activeConfigs) {
            try {
                scan(fc);
            } catch (Exception e) {
                // one bad config should never abort the whole scan cycle
                log.error("Scan failed for FileConfig id={} ({}/{}): {}",
                        fc.getFileConfigId(), fc.getClientName(), fc.getInterfaceName(), e.getMessage(), e);
            }
        }
    }

    // ------------------------------------------------------------------
    // Internal helpers
    // ------------------------------------------------------------------

    private FileAudit createNewFileAudit(FileConfig fileConfig, FileMetadata meta) {
        FileAudit audit = FileAudit.builder()
                .fileConfig(fileConfig)
                .actualFileName(meta.getFileName())
                .correlationId(buildCorrelationId(fileConfig, meta))
                .receivedDatetime(LocalDateTime.now())
                .status(FileStatus.RECEIVED)
                .overallResult(OverallResult.PENDING)
                .build();
        return fileAuditRepository.save(audit);
    }

    private String buildCorrelationId(FileConfig fileConfig, FileMetadata meta) {
        return "CORR-" + LocalDate.now() + "-" + fileConfig.getInterfaceName() + "-" + meta.getFileName().hashCode();
    }

    private void processStages(StorageProvider provider, FileConfig fileConfig, FileAudit fileAudit) {
        Integer runningRecordCount = fileAudit.getActualRecordCount();
        boolean allStagesPassed = true;
        boolean anyStageFailed = false;

        for (StageConfig stage : fileConfig.getStages()) {
            if (!stage.isActive()) continue;

            Optional<StageAudit> existing = stageAuditRepository
                    .findByFileAudit_FileAuditIdAndStageName(fileAudit.getFileAuditId(), stage.getStageName());

            if (existing.isPresent() && existing.get().getStageStatus() == StageStatus.COMPLETED) {
                // already validated in a previous scan cycle - carry the count forward and move on
                if (existing.get().getRecordCountAtStage() != null) {
                    runningRecordCount = existing.get().getRecordCountAtStage();
                }
                continue;
            }

            String location = resolveLocation(fileConfig, stage);
            String prefix = resolvePrefix(fileConfig, stage);

            LocalDateTime entryTime = LocalDateTime.now();
            FileCheckStrategy strategy = checkStrategyFactory.getStrategy(stage.getCheckType());
            CheckResult result = strategy.check(provider, fileConfig, stage, location, prefix,
                    fileAudit.getActualFileName(), runningRecordCount);

            StageAudit stageAudit = existing.orElseGet(() -> StageAudit.builder()
                    .fileAudit(fileAudit)
                    .stageName(stage.getStageName())
                    .entryDatetime(entryTime)
                    .build());

            stageAudit.setExitDatetime(LocalDateTime.now());
            stageAudit.setStageStatus(result.isPassed() ? StageStatus.COMPLETED : StageStatus.FAILED);
            stageAudit.setErrorMessage(result.isPassed() ? null : result.getMessage());
            if (result.getRecordCount() != null) {
                stageAudit.setRecordCountAtStage(result.getRecordCount());
                runningRecordCount = result.getRecordCount();
            }
            stageAuditRepository.save(stageAudit);

            log.info("Stage check [{}] file={} stage={} result={} :: {}",
                    fileConfig.getInterfaceName(), fileAudit.getActualFileName(),
                    stage.getStageName(), result.isPassed() ? "PASS" : "FAIL", result.getMessage());

            if (!result.isPassed()) {
                anyStageFailed = true;
                allStagesPassed = false;

                AlertType alertType = mapCheckTypeToAlertType(stage.getCheckType());
                alertService.raise(fileConfig, fileAudit, alertType, result.getMessage());

                // stop advancing this file through further stages until next scan cycle resolves it
                break;
            }
        }

        fileAudit.setActualRecordCount(runningRecordCount);
        if (allStagesPassed) {
            fileAudit.setStatus(FileStatus.COMPLETED);
            fileAudit.setOverallResult(OverallResult.SUCCESS);
        } else if (anyStageFailed) {
            fileAudit.setStatus(FileStatus.FAILED);
            fileAudit.setOverallResult(
                    fileAudit.getExpectedRecordCount() != null
                            && !fileAudit.getExpectedRecordCount().equals(runningRecordCount)
                            ? OverallResult.PARTIAL
                            : OverallResult.FAILED);
        } else {
            fileAudit.setStatus(FileStatus.IN_PROGRESS);
            fileAudit.setOverallResult(OverallResult.PENDING);
        }
        fileAudit.setUpdatedDate(LocalDateTime.now());
        fileAuditRepository.save(fileAudit);
    }

    /**
     * Flags a client/interface as MISSING for today if its expected window has closed
     * and no FILE_AUDIT row was created for it today.
     */
    private void checkForMissingFiles(FileConfig fileConfig) {
        if (fileConfig.getExpectedTimeWindowEnd() == null) return; // no SLA window configured, skip

        LocalTime now = LocalTime.now();
        if (now.isBefore(fileConfig.getExpectedTimeWindowEnd())) {
            return; // window still open, too early to call it missing
        }

        LocalDateTime startOfDay = LocalDate.now().atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1);

        List<FileAudit> todaysAudits = fileAuditRepository
                .findByFileConfig_FileConfigIdAndReceivedDatetimeBetween(
                        fileConfig.getFileConfigId(), startOfDay, endOfDay);

        if (todaysAudits.isEmpty()) {
            // avoid duplicate alerts: only raise once per day per config (simple heuristic check)
            log.warn("MISSING FILE: client={} interface={} expected by {} - nothing received today",
                    fileConfig.getClientName(), fileConfig.getInterfaceName(), fileConfig.getExpectedTimeWindowEnd());
            alertService.raise(fileConfig, null, AlertType.FILE_MISSING,
                    String.format("No file received for %s/%s. Expected window closed at %s.",
                            fileConfig.getClientName(), fileConfig.getInterfaceName(),
                            fileConfig.getExpectedTimeWindowEnd()));
        }
    }

    private AlertType mapCheckTypeToAlertType(CheckType checkType) {
        return switch (checkType) {
            case FILE_EXISTS -> AlertType.MOVEMENT_FAILED;
            case FILE_SIZE_GT_ZERO -> AlertType.MOVEMENT_FAILED;
            case MAX_AGE -> AlertType.MAX_AGE_EXCEEDED;
            case RECORD_COUNT_MATCH -> AlertType.COUNT_MISMATCH;
        };
    }

    private String resolveLocation(FileConfig fileConfig, StageConfig stage) {
        if (fileConfig.getStorageType() == StorageType.S3) {
            return fileConfig.getMonitorPath(); // bucket name lives on the FileConfig for S3
        }
        return (stage.getStagePath() != null && !stage.getStagePath().isBlank())
                ? stage.getStagePath()
                : fileConfig.getMonitorPath();
    }

    private String resolvePrefix(FileConfig fileConfig, StageConfig stage) {
        if (fileConfig.getStorageType() != StorageType.S3) {
            return null;
        }
        return (stage.getStagePath() != null && !stage.getStagePath().isBlank())
                ? stage.getStagePath()
                : fileConfig.getS3Prefix();
    }
}
