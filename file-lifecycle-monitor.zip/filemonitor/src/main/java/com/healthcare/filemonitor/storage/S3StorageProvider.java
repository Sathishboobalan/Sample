package com.healthcare.filemonitor.storage;

import com.healthcare.filemonitor.entity.enums.StorageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.core.exception.SdkException;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * Monitors files stored in AWS S3 buckets.
 *
 * Convention used across this provider:
 *  - "location" parameter = bucket name
 *  - "prefixOrNull"        = S3 key prefix (folder-equivalent), e.g. "ibx/inbound/"
 *  - file name matching happens against the key with the prefix stripped
 */
@Slf4j
@Component
public class S3StorageProvider implements StorageProvider {

    private final S3Client s3Client;

    public S3StorageProvider(S3Client s3Client) {
        this.s3Client = s3Client;
    }

    @Override
    public StorageType getStorageType() {
        return StorageType.S3;
    }

    @Override
    public List<FileMetadata> listFiles(String bucket, String prefix, String fileNameRegex) {
        List<FileMetadata> results = new ArrayList<>();
        Pattern pattern = (fileNameRegex == null || fileNameRegex.isBlank())
                ? null
                : Pattern.compile(fileNameRegex);

        String normalizedPrefix = prefix == null ? "" : prefix;

        try {
            ListObjectsV2Request.Builder requestBuilder = ListObjectsV2Request.builder()
                    .bucket(bucket)
                    .prefix(normalizedPrefix)
                    .delimiter("/"); // non-recursive: only "files" directly under prefix

            ListObjectsV2Response response;
            String continuationToken = null;

            do {
                ListObjectsV2Request request = requestBuilder
                        .continuationToken(continuationToken)
                        .build();
                response = s3Client.listObjectsV2(request);

                for (S3Object obj : response.contents()) {
                    String key = obj.key();
                    if (key.equals(normalizedPrefix)) continue; // skip the "folder" marker itself

                    String fileName = key.substring(normalizedPrefix.length());
                    if (fileName.isBlank() || fileName.contains("/")) continue; // skip nested "sub-folders"

                    if (pattern == null || pattern.matcher(fileName).matches()) {
                        results.add(FileMetadata.builder()
                                .fileName(fileName)
                                .fullPath(key)
                                .sizeInBytes(obj.size())
                                .lastModified(obj.lastModified())
                                .build());
                    }
                }
                continuationToken = response.nextContinuationToken();
            } while (Boolean.TRUE.equals(response.isTruncated()));

        } catch (SdkException e) {
            log.error("Failed to list S3 objects in bucket={} prefix={}: {}", bucket, prefix, e.getMessage(), e);
        }
        return results;
    }

    @Override
    public Optional<FileMetadata> getFileMetadata(String bucket, String prefix, String fileName) {
        String key = buildKey(prefix, fileName);
        try {
            HeadObjectResponse head = s3Client.headObject(HeadObjectRequest.builder()
                    .bucket(bucket)
                    .key(key)
                    .build());
            return Optional.of(FileMetadata.builder()
                    .fileName(fileName)
                    .fullPath(key)
                    .sizeInBytes(head.contentLength())
                    .lastModified(head.lastModified())
                    .build());
        } catch (NoSuchKeyException e) {
            return Optional.empty();
        } catch (SdkException e) {
            log.error("Failed to head S3 object bucket={} key={}: {}", bucket, key, e.getMessage(), e);
            return Optional.empty();
        }
    }

    @Override
    public boolean exists(String bucket, String prefix, String fileName) {
        String key = buildKey(prefix, fileName);
        try {
            s3Client.headObject(HeadObjectRequest.builder().bucket(bucket).key(key).build());
            return true;
        } catch (NoSuchKeyException e) {
            return false;
        } catch (SdkException e) {
            log.error("Failed to check existence of S3 object bucket={} key={}: {}", bucket, key, e.getMessage());
            return false;
        }
    }

    @Override
    public long countRecords(String bucket, String prefix, String fileName) {
        String key = buildKey(prefix, fileName);
        try (var responseStream = s3Client.getObject(
                GetObjectRequest.builder().bucket(bucket).key(key).build(),
                ResponseTransformer.toInputStream());
             BufferedReader reader = new BufferedReader(new InputStreamReader(responseStream, StandardCharsets.UTF_8))) {
            return reader.lines().count();
        } catch (NoSuchKeyException e) {
            return -1;
        } catch (IOException | SdkException e) {
            log.warn("Could not count records for s3://{}/{}: {}", bucket, key, e.getMessage());
            return -1;
        }
    }

    @Override
    public boolean isAvailable(String bucket) {
        try {
            s3Client.headBucket(HeadBucketRequest.builder().bucket(bucket).build());
            return true;
        } catch (SdkException e) {
            log.error("S3 bucket {} not accessible: {}", bucket, e.getMessage());
            return false;
        }
    }

    private String buildKey(String prefix, String fileName) {
        if (prefix == null || prefix.isBlank()) return fileName;
        return prefix.endsWith("/") ? prefix + fileName : prefix + "/" + fileName;
    }
}
