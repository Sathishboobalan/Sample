package com.healthcare.filemonitor.service;

import com.healthcare.filemonitor.entity.FileConfig;
import com.healthcare.filemonitor.repository.FileConfigRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.stream.Collectors;

/**
 * Holds active FileConfig (with nested StageConfig) rows in memory so the scheduler
 * doesn't hit the DB on every scan cycle. Refreshed:
 *   1. On application startup
 *   2. On a fixed schedule (filemonitor.route-cache.refresh-cron)
 *   3. On demand via POST /api/monitor/cache/refresh (see MonitorController)
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RouteCacheService {

    private final FileConfigRepository fileConfigRepository;

    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private volatile Map<Long, FileConfig> cache = new ConcurrentHashMap<>();
    private volatile java.time.LocalDateTime lastRefreshed;

    @PostConstruct
    public void init() {
        refresh();
    }

    /** Scheduled background refresh - every 5 minutes by default, configurable. */
    @Scheduled(cron = "${filemonitor.route-cache.refresh-cron:0 */5 * * * *}")
    public void scheduledRefresh() {
        log.debug("Running scheduled RouteCache refresh");
        refresh();
    }

    /** Force refresh - called by REST endpoint after a config change in DB. */
    public synchronized void refresh() {
        lock.writeLock().lock();
        try {
            List<FileConfig> activeConfigs = fileConfigRepository.findByActiveFlag("Y");
            Map<Long, FileConfig> newCache = activeConfigs.stream()
                    .collect(Collectors.toConcurrentMap(FileConfig::getFileConfigId, fc -> fc));
            this.cache = newCache;
            this.lastRefreshed = java.time.LocalDateTime.now();
            log.info("RouteCache refreshed: {} active file configs loaded", newCache.size());
        } catch (Exception e) {
            log.error("RouteCache refresh failed, keeping previous cache ({} entries): {}",
                    cache.size(), e.getMessage(), e);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public List<FileConfig> getAllActiveConfigs() {
        lock.readLock().lock();
        try {
            return Collections.unmodifiableList(List.copyOf(cache.values()));
        } finally {
            lock.readLock().unlock();
        }
    }

    public FileConfig getById(Long fileConfigId) {
        lock.readLock().lock();
        try {
            return cache.get(fileConfigId);
        } finally {
            lock.readLock().unlock();
        }
    }

    public java.time.LocalDateTime getLastRefreshed() {
        return lastRefreshed;
    }

    public int size() {
        return cache.size();
    }
}
