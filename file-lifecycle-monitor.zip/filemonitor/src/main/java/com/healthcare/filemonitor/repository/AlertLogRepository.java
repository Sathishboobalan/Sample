package com.healthcare.filemonitor.repository;

import com.healthcare.filemonitor.entity.AlertLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AlertLogRepository extends JpaRepository<AlertLog, Long> {
    List<AlertLog> findByResolvedFlag(String resolvedFlag);
    List<AlertLog> findByFileConfig_FileConfigId(Long fileConfigId);
}
