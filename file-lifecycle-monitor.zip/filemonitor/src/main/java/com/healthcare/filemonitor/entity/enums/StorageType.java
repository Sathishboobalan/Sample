package com.healthcare.filemonitor.entity.enums;

/** Backend where a monitored path physically lives. */
public enum StorageType {
    LOCAL,
    FSX,
    S3
}
