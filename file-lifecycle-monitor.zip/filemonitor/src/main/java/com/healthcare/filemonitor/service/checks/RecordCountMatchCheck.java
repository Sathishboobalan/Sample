package com.healthcare.filemonitor.service.checks;

import com.healthcare.filemonitor.entity.FileConfig;
import com.healthcare.filemonitor.entity.StageConfig;
import com.healthcare.filemonitor.entity.enums.CheckType;
import com.healthcare.filemonitor.storage.StorageProvider;
import org.springframework.stereotype.Component;

/**
 * Compares actual record (line) count of a file against an expected count.
 * Expected count is typically sourced from an upstream ack/manifest file or a prior stage's count;
 * pass null expectedRecordCount to skip the comparison and just report the count (first-stage capture).
 */
@Component
public class RecordCountMatchCheck implements FileCheckStrategy {

    @Override
    public CheckType supports() {
        return CheckType.RECORD_COUNT_MATCH;
    }

    @Override
    public CheckResult check(StorageProvider provider, FileConfig fileConfig, StageConfig stageConfig,
                              String resolvedLocation, String resolvedPrefix, String fileName,
                              Integer expectedRecordCount) {
        long actualCount = provider.countRecords(resolvedLocation, resolvedPrefix, fileName);
        if (actualCount < 0) {
            return CheckResult.builder()
                    .passed(false)
                    .message("Could not determine record count for " + fileName)
                    .build();
        }

        if (expectedRecordCount == null) {
            // No baseline yet (e.g. first stage) - just capture the count as the new baseline.
            return CheckResult.builder()
                    .passed(true)
                    .message("Record count captured: " + actualCount)
                    .recordCount((int) actualCount)
                    .build();
        }

        boolean matches = actualCount == expectedRecordCount;
        String msg = matches
                ? String.format("Record count matches: %d", actualCount)
                : String.format("Record count mismatch for %s: expected %d, actual %d",
                        fileName, expectedRecordCount, actualCount);

        return CheckResult.builder()
                .passed(matches)
                .message(msg)
                .recordCount((int) actualCount)
                .build();
    }
}
