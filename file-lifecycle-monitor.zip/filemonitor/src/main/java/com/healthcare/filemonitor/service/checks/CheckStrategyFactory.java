package com.healthcare.filemonitor.service.checks;

import com.healthcare.filemonitor.entity.enums.CheckType;
import org.springframework.stereotype.Component;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

@Component
public class CheckStrategyFactory {

    private final Map<CheckType, FileCheckStrategy> strategies = new EnumMap<>(CheckType.class);

    public CheckStrategyFactory(List<FileCheckStrategy> allStrategies) {
        for (FileCheckStrategy strategy : allStrategies) {
            strategies.put(strategy.supports(), strategy);
        }
    }

    public FileCheckStrategy getStrategy(CheckType checkType) {
        FileCheckStrategy strategy = strategies.get(checkType);
        if (strategy == null) {
            throw new IllegalArgumentException("No FileCheckStrategy registered for: " + checkType);
        }
        return strategy;
    }
}
