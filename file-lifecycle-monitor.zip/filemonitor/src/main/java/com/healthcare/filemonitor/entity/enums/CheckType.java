package com.healthcare.filemonitor.entity.enums;

/** Type of validation performed at a given stage. */
public enum CheckType {
    FILE_EXISTS,
    FILE_SIZE_GT_ZERO,
    MAX_AGE,
    RECORD_COUNT_MATCH
}
