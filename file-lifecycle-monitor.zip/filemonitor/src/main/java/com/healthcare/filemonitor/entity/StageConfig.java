package com.healthcare.filemonitor.entity;

import com.healthcare.filemonitor.entity.enums.CheckType;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "STAGE_CONFIG")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StageConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "stage_config_id")
    private Long stageConfigId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_config_id", nullable = false)
    private FileConfig fileConfig;

    @Column(name = "stage_name", nullable = false, length = 50)
    private String stageName; // INBOUND, MOVEIT, INTEGRATION_PLUS, EDIFECS, OUTBOUND, ARCHIVE ...

    @Column(name = "stage_sequence", nullable = false)
    private Integer stageSequence;

    @Enumerated(EnumType.STRING)
    @Column(name = "check_type", length = 50)
    private CheckType checkType;

    @Column(name = "depends_on_ack", length = 1)
    @Builder.Default
    private String dependsOnAck = "N";

    @Column(name = "max_wait_minutes")
    private Integer maxWaitMinutes;

    /** Path override for this specific stage; if null, falls back to FileConfig.monitorPath */
    @Column(name = "stage_path", length = 500)
    private String stagePath;

    @Column(name = "active_flag", length = 1)
    @Builder.Default
    private String activeFlag = "Y";

    public boolean isActive() {
        return "Y".equalsIgnoreCase(activeFlag);
    }

    public boolean dependsOnAck() {
        return "Y".equalsIgnoreCase(dependsOnAck);
    }
}
