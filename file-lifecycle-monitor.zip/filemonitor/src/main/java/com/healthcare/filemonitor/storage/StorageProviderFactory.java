package com.healthcare.filemonitor.storage;

import com.healthcare.filemonitor.entity.enums.StorageType;
import com.healthcare.filemonitor.exception.StorageProviderNotFoundException;
import org.springframework.stereotype.Component;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Resolves the correct StorageProvider implementation for a given StorageType at runtime.
 * Since storage_type is a column on FILE_CONFIG (data-driven, not environment-driven),
 * a single running instance can monitor LOCAL + FSX + S3 sources simultaneously —
 * this factory is what makes that possible without profile-based bean exclusion.
 */
@Component
public class StorageProviderFactory {

    private final Map<StorageType, StorageProvider> providerMap = new EnumMap<>(StorageType.class);

    public StorageProviderFactory(List<StorageProvider> providers) {
        for (StorageProvider provider : providers) {
            providerMap.put(provider.getStorageType(), provider);
        }
    }

    public StorageProvider getProvider(StorageType storageType) {
        StorageProvider provider = providerMap.get(storageType);
        if (provider == null) {
            throw new StorageProviderNotFoundException("No StorageProvider registered for type: " + storageType);
        }
        return provider;
    }
}
