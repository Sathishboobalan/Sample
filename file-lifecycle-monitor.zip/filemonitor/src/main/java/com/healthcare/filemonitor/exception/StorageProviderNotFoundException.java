package com.healthcare.filemonitor.exception;

public class StorageProviderNotFoundException extends RuntimeException {
    public StorageProviderNotFoundException(String message) {
        super(message);
    }
}
