package com.healthcare.filemonitor.entity;

import com.healthcare.filemonitor.entity.enums.FileStatus;
import com.healthcare.filemonitor.entity.enums.OverallResult;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "FILE_AUDIT")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FileAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "file_audit_id")
    private Long fileAuditId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_config_id", nullable = false)
    private FileConfig fileConfig;

    @Column(name = "actual_file_name", length = 300)
    private String actualFileName;

    @Column(name = "correlation_id", length = 100)
    private String correlationId;

    @Column(name = "received_datetime")
    private LocalDateTime receivedDatetime;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20)
    private FileStatus status;

    @Column(name = "expected_record_count")
    private Integer expectedRecordCount;

    @Column(name = "actual_record_count")
    private Integer actualRecordCount;

    @Enumerated(EnumType.STRING)
    @Column(name = "overall_result", length = 20)
    private OverallResult overallResult;

    @Column(name = "created_date")
    @Builder.Default
    private LocalDateTime createdDate = LocalDateTime.now();

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @OneToMany(mappedBy = "fileAudit", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<StageAudit> stageAudits = new ArrayList<>();
}
