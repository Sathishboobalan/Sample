package com.healthcare.filemonitor.storage;

import com.healthcare.filemonitor.entity.enums.StorageType;

import java.util.List;
import java.util.Optional;

/**
 * Common contract for listing/inspecting files on any backing storage.
 * Implementations: LocalStorageProvider, FsxStorageProvider, S3StorageProvider.
 *
 * All path/prefix arguments are backend-specific:
 *  - LOCAL / FSX -> absolute filesystem directory path
 *  - S3          -> "bucketName" as location, and prefix passed separately
 */
public interface StorageProvider {

    StorageType getStorageType();

    /**
     * List all files directly under the given location that match the supplied regex.
     * Non-recursive by design (matches how these interfaces drop files: flat inbound/outbound folders).
     *
     * @param location  directory path (LOCAL/FSX) or bucket name (S3)
     * @param prefixOrNull  S3 key prefix; ignored for LOCAL/FSX
     * @param fileNameRegex regex the file name must match; null/empty = match all
     */
    List<FileMetadata> listFiles(String location, String prefixOrNull, String fileNameRegex);

    /**
     * Fetch metadata for one specific file if present.
     */
    Optional<FileMetadata> getFileMetadata(String location, String prefixOrNull, String fileName);

    boolean exists(String location, String prefixOrNull, String fileName);

    /**
     * Best-effort line/record count for text-based files (used by RECORD_COUNT_MATCH check).
     * Returns -1 if the count cannot be determined (e.g. binary file, provider not able to stream).
     */
    long countRecords(String location, String prefixOrNull, String fileName);

    /**
     * Lightweight connectivity/availability check for the backend (used by health indicators).
     */
    boolean isAvailable(String location);
}
