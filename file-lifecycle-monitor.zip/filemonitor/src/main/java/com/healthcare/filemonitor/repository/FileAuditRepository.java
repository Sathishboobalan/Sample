package com.healthcare.filemonitor.repository;

import com.healthcare.filemonitor.entity.FileAudit;
import com.healthcare.filemonitor.entity.enums.FileStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface FileAuditRepository extends JpaRepository<FileAudit, Long> {

    Optional<FileAudit> findByFileConfig_FileConfigIdAndActualFileName(Long fileConfigId, String actualFileName);

    List<FileAudit> findByFileConfig_FileConfigIdAndReceivedDatetimeBetween(
            Long fileConfigId, LocalDateTime start, LocalDateTime end);

    List<FileAudit> findByStatus(FileStatus status);

    List<FileAudit> findByReceivedDatetimeBetween(LocalDateTime start, LocalDateTime end);
}
