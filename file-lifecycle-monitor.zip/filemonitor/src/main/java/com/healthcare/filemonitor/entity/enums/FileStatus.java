package com.healthcare.filemonitor.entity.enums;

public enum FileStatus {
    RECEIVED,
    IN_PROGRESS,
    COMPLETED,
    FAILED,
    MISSING
}
