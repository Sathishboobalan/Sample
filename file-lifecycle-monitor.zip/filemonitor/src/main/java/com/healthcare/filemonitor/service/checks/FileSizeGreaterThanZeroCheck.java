package com.healthcare.filemonitor.service.checks;

import com.healthcare.filemonitor.entity.FileConfig;
import com.healthcare.filemonitor.entity.StageConfig;
import com.healthcare.filemonitor.entity.enums.CheckType;
import com.healthcare.filemonitor.storage.FileMetadata;
import com.healthcare.filemonitor.storage.StorageProvider;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class FileSizeGreaterThanZeroCheck implements FileCheckStrategy {

    @Override
    public CheckType supports() {
        return CheckType.FILE_SIZE_GT_ZERO;
    }

    @Override
    public CheckResult check(StorageProvider provider, FileConfig fileConfig, StageConfig stageConfig,
                              String resolvedLocation, String resolvedPrefix, String fileName,
                              Integer expectedRecordCount) {
        Optional<FileMetadata> metadata = provider.getFileMetadata(resolvedLocation, resolvedPrefix, fileName);
        if (metadata.isEmpty()) {
            return CheckResult.fail("File not found for size check: " + fileName);
        }
        if (metadata.get().isEmpty()) {
            return CheckResult.fail("File is zero bytes: " + fileName);
        }
        return CheckResult.pass("File size OK (" + metadata.get().getSizeInBytes() + " bytes): " + fileName);
    }
}
