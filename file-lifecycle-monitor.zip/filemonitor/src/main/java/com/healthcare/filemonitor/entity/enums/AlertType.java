package com.healthcare.filemonitor.entity.enums;

public enum AlertType {
    FILE_MISSING,
    COUNT_MISMATCH,
    MOVEMENT_FAILED,
    JOB_FAILED,
    ACK_TIMEOUT,
    MAX_AGE_EXCEEDED
}
