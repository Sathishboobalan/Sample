package com.healthcare.filemonitor.service;

import com.healthcare.filemonitor.entity.AlertLog;
import com.healthcare.filemonitor.entity.FileAudit;
import com.healthcare.filemonitor.entity.FileConfig;
import com.healthcare.filemonitor.entity.enums.AlertType;
import com.healthcare.filemonitor.repository.AlertLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Raises alerts into ALERT_LOG. Kept intentionally simple (DB write only) so that
 * a notification channel (email/Slack/PagerDuty) can be layered on top later
 * without touching the monitoring logic itself - e.g. a @Scheduled job that polls
 * unresolved ALERT_LOG rows and dispatches notifications.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AlertService {

    private final AlertLogRepository alertLogRepository;

    public void raise(FileConfig fileConfig, FileAudit fileAuditOrNull, AlertType alertType, String message) {
        AlertLog alert = AlertLog.builder()
                .fileConfig(fileConfig)
                .fileAudit(fileAuditOrNull)
                .alertType(alertType)
                .alertMessage(message)
                .build();
        alertLogRepository.save(alert);
        log.warn("ALERT [{}] client={} interface={} :: {}",
                alertType, fileConfig.getClientName(), fileConfig.getInterfaceName(), message);
    }
}
