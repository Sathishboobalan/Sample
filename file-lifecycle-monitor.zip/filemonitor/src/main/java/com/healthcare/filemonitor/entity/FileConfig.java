package com.healthcare.filemonitor.entity;

import com.healthcare.filemonitor.entity.enums.StorageType;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Configuration for one monitored interface/file-type for a given client.
 * Drives what to expect, where it lives (storage type + path), and its naming pattern.
 */
@Entity
@Table(name = "FILE_CONFIG")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FileConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "file_config_id")
    private Long fileConfigId;

    @Column(name = "client_name", nullable = false, length = 50)
    private String clientName;

    @Column(name = "interface_name", nullable = false, length = 50)
    private String interfaceName;

    @Column(name = "file_name_pattern", nullable = false, length = 200)
    private String fileNamePattern;

    /** Regex derived from file_name_pattern, used at runtime to match actual files. */
    @Column(name = "file_name_regex", length = 300)
    private String fileNameRegex;

    @Enumerated(EnumType.STRING)
    @Column(name = "storage_type", nullable = false, length = 20)
    private StorageType storageType;

    /**
     * Physical location to monitor.
     * LOCAL/FSX -> absolute filesystem path, e.g. /mnt/fsx/ibx/inbound
     * S3        -> bucket name (key prefix goes in s3Prefix)
     */
    @Column(name = "monitor_path", nullable = false, length = 500)
    private String monitorPath;

    /** Only used when storageType = S3 */
    @Column(name = "s3_prefix", length = 500)
    private String s3Prefix;

    @Column(name = "source_system", length = 50)
    private String sourceSystem;

    @Column(name = "target_system", length = 50)
    private String targetSystem;

    @Column(name = "expected_frequency", length = 20)
    private String expectedFrequency; // DAILY, WEEKLY, ON_DEMAND

    @Column(name = "expected_time_window_start")
    private LocalTime expectedTimeWindowStart;

    @Column(name = "expected_time_window_end")
    private LocalTime expectedTimeWindowEnd;

    @Column(name = "ack_required", length = 1)
    private String ackRequired; // Y/N

    @Column(name = "active_flag", length = 1)
    @Builder.Default
    private String activeFlag = "Y";

    @Column(name = "created_date")
    @Builder.Default
    private LocalDateTime createdDate = LocalDateTime.now();

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @OneToMany(mappedBy = "fileConfig", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @OrderBy("stageSequence ASC")
    @Builder.Default
    private List<StageConfig> stages = new ArrayList<>();

    public boolean isActive() {
        return "Y".equalsIgnoreCase(activeFlag);
    }

    public boolean isAckRequired() {
        return "Y".equalsIgnoreCase(ackRequired);
    }
}
