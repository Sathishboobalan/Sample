package com.healthcare.filemonitor.entity.enums;

public enum OverallResult {
    SUCCESS,
    PARTIAL,
    FAILED,
    PENDING
}
