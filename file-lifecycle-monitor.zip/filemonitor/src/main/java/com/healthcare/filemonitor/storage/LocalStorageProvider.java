package com.healthcare.filemonitor.storage;

import com.healthcare.filemonitor.entity.enums.StorageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Monitors plain local filesystem directories.
 * Used for local/dev testing where paths are simple mounted or local disk locations.
 */
@Slf4j
@Component
public class LocalStorageProvider implements StorageProvider {

    @Override
    public StorageType getStorageType() {
        return StorageType.LOCAL;
    }

    @Override
    public List<FileMetadata> listFiles(String location, String prefixOrNull, String fileNameRegex) {
        List<FileMetadata> results = new ArrayList<>();
        Path dir = Paths.get(location);

        if (!Files.isDirectory(dir)) {
            log.warn("LOCAL path does not exist or is not a directory: {}", location);
            return results;
        }

        Pattern pattern = (fileNameRegex == null || fileNameRegex.isBlank())
                ? null
                : Pattern.compile(fileNameRegex);

        try (Stream<Path> stream = Files.list(dir)) {
            stream.filter(Files::isRegularFile)
                  .forEach(path -> {
                      String fileName = path.getFileName().toString();
                      if (pattern == null || pattern.matcher(fileName).matches()) {
                          results.add(toMetadata(path));
                      }
                  });
        } catch (IOException e) {
            log.error("Failed to list files in LOCAL directory {}: {}", location, e.getMessage(), e);
        }
        return results;
    }

    @Override
    public Optional<FileMetadata> getFileMetadata(String location, String prefixOrNull, String fileName) {
        Path path = Paths.get(location, fileName);
        if (!Files.exists(path)) {
            return Optional.empty();
        }
        return Optional.of(toMetadata(path));
    }

    @Override
    public boolean exists(String location, String prefixOrNull, String fileName) {
        return Files.exists(Paths.get(location, fileName));
    }

    @Override
    public long countRecords(String location, String prefixOrNull, String fileName) {
        Path path = Paths.get(location, fileName);
        if (!Files.exists(path)) {
            return -1;
        }
        try (BufferedReader reader = Files.newBufferedReader(path)) {
            return reader.lines().count();
        } catch (IOException e) {
            log.warn("Could not count records for {}: {}", path, e.getMessage());
            return -1;
        }
    }

    @Override
    public boolean isAvailable(String location) {
        return Files.isDirectory(Paths.get(location));
    }

    private FileMetadata toMetadata(Path path) {
        try {
            BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class);
            return FileMetadata.builder()
                    .fileName(path.getFileName().toString())
                    .fullPath(path.toAbsolutePath().toString())
                    .sizeInBytes(attrs.size())
                    .lastModified(Instant.ofEpochMilli(attrs.lastModifiedTime().toMillis()))
                    .build();
        } catch (IOException e) {
            log.error("Failed reading attributes for {}: {}", path, e.getMessage());
            return FileMetadata.builder()
                    .fileName(path.getFileName().toString())
                    .fullPath(path.toAbsolutePath().toString())
                    .sizeInBytes(0)
                    .lastModified(Instant.EPOCH)
                    .build();
        }
    }
}
