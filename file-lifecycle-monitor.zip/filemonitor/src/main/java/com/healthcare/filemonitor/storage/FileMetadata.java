package com.healthcare.filemonitor.storage;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * Uniform representation of a file's metadata regardless of which backend
 * (local disk, FSx-mounted path, or S3) it was retrieved from.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileMetadata {

    private String fileName;

    /** Full path (local/FSX) or key (S3) */
    private String fullPath;

    private long sizeInBytes;

    private Instant lastModified;

    public boolean isEmpty() {
        return sizeInBytes <= 0;
    }
}
