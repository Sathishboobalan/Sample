package com.healthcare.filemonitor.service.checks;

import com.healthcare.filemonitor.entity.FileConfig;
import com.healthcare.filemonitor.entity.StageConfig;
import com.healthcare.filemonitor.entity.enums.CheckType;
import com.healthcare.filemonitor.storage.FileMetadata;
import com.healthcare.filemonitor.storage.StorageProvider;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.Optional;

/**
 * Verifies a file did not sit in this stage longer than StageConfig.maxWaitMinutes.
 * Uses the file's last-modified timestamp as a proxy for "how long it has been sitting here".
 */
@Component
public class MaxAgeCheck implements FileCheckStrategy {

    @Override
    public CheckType supports() {
        return CheckType.MAX_AGE;
    }

    @Override
    public CheckResult check(StorageProvider provider, FileConfig fileConfig, StageConfig stageConfig,
                              String resolvedLocation, String resolvedPrefix, String fileName,
                              Integer expectedRecordCount) {
        Optional<FileMetadata> metadata = provider.getFileMetadata(resolvedLocation, resolvedPrefix, fileName);
        if (metadata.isEmpty()) {
            return CheckResult.fail("File not found for age check: " + fileName);
        }

        Integer maxWaitMinutes = stageConfig.getMaxWaitMinutes();
        if (maxWaitMinutes == null) {
            return CheckResult.pass("No max-age configured for stage " + stageConfig.getStageName());
        }

        Duration age = Duration.between(metadata.get().getLastModified(), Instant.now());
        if (age.toMinutes() > maxWaitMinutes) {
            return CheckResult.fail(String.format(
                    "File %s exceeded max age at stage %s: %d min elapsed (limit %d min)",
                    fileName, stageConfig.getStageName(), age.toMinutes(), maxWaitMinutes));
        }
        return CheckResult.pass(String.format("File %s within age limit (%d/%d min)",
                fileName, age.toMinutes(), maxWaitMinutes));
    }
}
