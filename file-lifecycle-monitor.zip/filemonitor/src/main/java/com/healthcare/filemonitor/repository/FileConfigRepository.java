package com.healthcare.filemonitor.repository;

import com.healthcare.filemonitor.entity.FileConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FileConfigRepository extends JpaRepository<FileConfig, Long> {
    List<FileConfig> findByActiveFlag(String activeFlag);
    List<FileConfig> findByClientNameAndActiveFlag(String clientName, String activeFlag);
}
