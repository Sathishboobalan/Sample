package com.healthcare.filemonitor.service.checks;

import com.healthcare.filemonitor.entity.FileConfig;
import com.healthcare.filemonitor.entity.StageConfig;
import com.healthcare.filemonitor.entity.enums.CheckType;
import com.healthcare.filemonitor.storage.StorageProvider;
import org.springframework.stereotype.Component;

@Component
public class FileExistsCheck implements FileCheckStrategy {

    @Override
    public CheckType supports() {
        return CheckType.FILE_EXISTS;
    }

    @Override
    public CheckResult check(StorageProvider provider, FileConfig fileConfig, StageConfig stageConfig,
                              String resolvedLocation, String resolvedPrefix, String fileName,
                              Integer expectedRecordCount) {
        boolean exists = provider.exists(resolvedLocation, resolvedPrefix, fileName);
        return exists
                ? CheckResult.pass("File exists: " + fileName)
                : CheckResult.fail("File not found: " + fileName + " at " + resolvedLocation);
    }
}
