package com.healthcare.filemonitor.repository;

import com.healthcare.filemonitor.entity.StageAudit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface StageAuditRepository extends JpaRepository<StageAudit, Long> {
    List<StageAudit> findByFileAudit_FileAuditIdOrderByEntryDatetimeAsc(Long fileAuditId);
    Optional<StageAudit> findByFileAudit_FileAuditIdAndStageName(Long fileAuditId, String stageName);
}
