package com.healthcare.filemonitor.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

/**
 * S3Client bean.
 *
 * local/dev: falls back to DefaultCredentialsProvider (works with local ~/.aws/credentials
 *            or LocalStack if filemonitor.aws.s3.endpoint-override is set).
 * SIT/prod:  typically relies on an instance/task IAM role, so access-key/secret-key
 *            properties are left blank and DefaultCredentialsProvider picks up the role.
 *            Explicit static keys are only used if both properties are supplied
 *            (e.g. for local testing against a real bucket).
 */
@Configuration
public class AwsConfig {

    @Value("${filemonitor.aws.region:us-east-1}")
    private String region;

    @Value("${filemonitor.aws.access-key:}")
    private String accessKey;

    @Value("${filemonitor.aws.secret-key:}")
    private String secretKey;

    @Value("${filemonitor.aws.s3.endpoint-override:}")
    private String endpointOverride;

    @Bean
    public S3Client s3Client() {
        AwsCredentialsProvider credentialsProvider = (!accessKey.isBlank() && !secretKey.isBlank())
                ? StaticCredentialsProvider.create(AwsBasicCredentials.create(accessKey, secretKey))
                : DefaultCredentialsProvider.create();

        S3Client.Builder builder = S3Client.builder()
                .region(Region.of(region))
                .credentialsProvider(credentialsProvider);

        if (endpointOverride != null && !endpointOverride.isBlank()) {
            builder.endpointOverride(java.net.URI.create(endpointOverride));
        }

        return builder.build();
    }
}
