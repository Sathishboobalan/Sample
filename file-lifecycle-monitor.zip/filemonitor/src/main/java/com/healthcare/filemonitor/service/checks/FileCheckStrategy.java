package com.healthcare.filemonitor.service.checks;

import com.healthcare.filemonitor.entity.FileConfig;
import com.healthcare.filemonitor.entity.StageConfig;
import com.healthcare.filemonitor.entity.enums.CheckType;
import com.healthcare.filemonitor.storage.StorageProvider;

/**
 * Strategy contract for one CheckType (FILE_EXISTS, FILE_SIZE_GT_ZERO, MAX_AGE, RECORD_COUNT_MATCH).
 * Implementations are stateless and resolved at runtime via CheckStrategyFactory.
 */
public interface FileCheckStrategy {

    CheckType supports();

    CheckResult check(StorageProvider provider,
                       FileConfig fileConfig,
                       StageConfig stageConfig,
                       String resolvedLocation,
                       String resolvedPrefix,
                       String fileName,
                       Integer expectedRecordCount);
}
