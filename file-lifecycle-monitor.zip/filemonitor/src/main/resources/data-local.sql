-- Sample seed data for local/H2 testing.
-- Creates a LOCAL-storage IBX/APPIN config pointing at a temp directory,
-- so you can literally drop a file into /tmp/filemonitor/ibx/inbound and watch it get tracked.

INSERT INTO FILE_CONFIG
(file_config_id, client_name, interface_name, file_name_pattern, file_name_regex, storage_type, monitor_path, s3_prefix, source_system, target_system, expected_frequency, expected_time_window_start, expected_time_window_end, ack_required, active_flag)
VALUES
(1, 'IBX', 'APPIN', 'IBXAPPINYYYYMMDDHHMMSSP.txt', 'IBXAPPIN.*\.txt', 'LOCAL', '/tmp/filemonitor/ibx/inbound', NULL, 'IFG', 'ADV', 'DAILY', '00:00:00', '23:59:00', 'Y', 'Y'),
(2, 'IBX', 'OEC', 'H5361_YYYY-MM-DD_PPPP.txt', 'H5361_.*\.txt', 'LOCAL', '/tmp/filemonitor/ibx/oec-inbound', NULL, 'IFG', 'ADV', 'DAILY', '00:00:00', '23:59:00', 'N', 'Y');

INSERT INTO STAGE_CONFIG
(stage_config_id, file_config_id, stage_name, stage_sequence, check_type, depends_on_ack, max_wait_minutes, stage_path, active_flag)
VALUES
(1, 1, 'INBOUND', 1, 'FILE_EXISTS', 'N', 30, '/tmp/filemonitor/ibx/inbound', 'Y'),
(2, 1, 'MOVEIT',  2, 'FILE_SIZE_GT_ZERO', 'N', 15, '/tmp/filemonitor/ibx/moveit', 'Y'),
(3, 1, 'INTEGRATION_PLUS', 3, 'RECORD_COUNT_MATCH', 'Y', 60, '/tmp/filemonitor/ibx/integration-plus', 'Y'),
(4, 1, 'OUTBOUND', 4, 'FILE_EXISTS', 'N', 30, '/tmp/filemonitor/ibx/outbound', 'Y'),
(5, 1, 'ARCHIVE',  5, 'FILE_EXISTS', 'N', 15, '/tmp/filemonitor/ibx/archive', 'Y'),

(6, 2, 'INBOUND', 1, 'FILE_EXISTS', 'N', 30, '/tmp/filemonitor/ibx/oec-inbound', 'Y'),
(7, 2, 'INTEGRATION_PLUS', 2, 'RECORD_COUNT_MATCH', 'N', 60, '/tmp/filemonitor/ibx/oec-integration-plus', 'Y'),
(8, 2, 'ARCHIVE', 3, 'FILE_EXISTS', 'N', 15, '/tmp/filemonitor/ibx/oec-archive', 'Y');
