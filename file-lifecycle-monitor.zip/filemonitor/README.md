# File Lifecycle Monitoring System

Spring Boot service that monitors file movement across the Inbound → Staging/MoveIT →
Processing/Integration+ → Outbound → Archive lifecycle, for files sitting on **local disk**,
**AWS FSx** (NFS/SMB-mounted), or **AWS S3** — all from one codebase, selected per-interface
via configuration (no profile switching needed to change storage type).

## How storage selection works

`FILE_CONFIG.storage_type` = `LOCAL` | `FSX` | `S3` drives everything. At scan time,
`StorageProviderFactory` looks up the matching `StorageProvider` bean:

| storage_type | Provider              | monitor_path means...          |
|--------------|------------------------|--------------------------------|
| LOCAL        | LocalStorageProvider    | absolute filesystem directory  |
| FSX          | FsxStorageProvider       | absolute mounted path (NFS/SMB), same API as LOCAL but with retry/backoff for transient network I/O errors |
| S3           | S3StorageProvider         | S3 bucket name (key prefix goes in `s3_prefix` / `stage_path`) |

A single running instance can monitor all three simultaneously — one FILE_CONFIG row
per interface, each can point at a different backend.

## Project layout

```
storage/       StorageProvider interface + Local/Fsx/S3 implementations + factory
entity/        JPA entities matching the FILE_CONFIG / STAGE_CONFIG / FILE_AUDIT /
               STAGE_AUDIT / ALERT_LOG schema
service/
  checks/      Strategy pattern for FILE_EXISTS, FILE_SIZE_GT_ZERO, MAX_AGE,
               RECORD_COUNT_MATCH
  RouteCacheService     in-memory cache of active configs, scheduled + on-demand refresh
  FileMonitoringService core scan/stage-walk/audit orchestration
  AlertService          writes ALERT_LOG rows
scheduler/     FileMonitorScheduler - periodic scan trigger (fixedDelay, non-overlapping)
controller/    REST endpoints to trigger scans / refresh cache / view audit trail
config/        AwsConfig (S3Client bean)
```

## Running locally

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

This uses an in-memory H2 DB and seeds two sample IBX FILE_CONFIG rows pointing at
`/tmp/filemonitor/...`. To see it work end-to-end:

```bash
mkdir -p /tmp/filemonitor/ibx/inbound
echo -e "line1\nline2\nline3" > /tmp/filemonitor/ibx/inbound/IBXAPPIN20260720061500P.txt
```

Within `filemonitor.scan.fixed-delay-millis` (30s in local profile) the scheduler will
pick it up, create a FILE_AUDIT row (status=RECEIVED → IN_PROGRESS), and start walking
it through the configured stages. Since only the INBOUND folder has the file, later
stages (MOVEIT, INTEGRATION_PLUS, etc.) will fail their FILE_EXISTS/RECORD_COUNT_MATCH
checks and an ALERT_LOG row will be written — this is expected until you also drop
matching files in `/tmp/filemonitor/ibx/moveit`, `/tmp/filemonitor/ibx/integration-plus`, etc.

H2 console: http://localhost:8080/h2-console (JDBC URL: `jdbc:h2:mem:filemonitor`)

## REST endpoints

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/monitor/cache/refresh` | force-refresh in-memory config cache after a DB change |
| GET  | `/api/monitor/cache/status` | cache size / last refresh time / scan-in-progress flag |
| POST | `/api/monitor/scan/trigger` | run a scan cycle immediately for all active configs |
| POST | `/api/monitor/scan/trigger/{fileConfigId}` | run a scan for one interface only |
| GET  | `/api/monitor/audit/{fileAuditId}` | full stage-by-stage audit trail for one file |

## Configuring an S3-backed interface

```sql
INSERT INTO FILE_CONFIG (client_name, interface_name, file_name_regex, storage_type, monitor_path, s3_prefix, active_flag)
VALUES ('Clover', 'CMS_FILE', 'CLV_CMS_.*\.txt', 'S3', 'clover-prod-bucket', 'inbound/', 'Y');
```

`monitor_path` = bucket name, `s3_prefix` = key prefix (folder-equivalent). Per-stage
overrides go in `STAGE_CONFIG.stage_path` (also treated as a key prefix for S3 stages).

## Configuring an FSx-backed interface

FSx is mounted by the OS, so `monitor_path` is just the mounted path, e.g.:

```sql
INSERT INTO FILE_CONFIG (client_name, interface_name, file_name_regex, storage_type, monitor_path, active_flag)
VALUES ('AmeriBen', 'GENERIC_INTERFACE', 'AMB_.*\.txt', 'FSX', '/mnt/fsx/ameriben/inbound', 'Y');
```

Retry/backoff for transient network-filesystem errors is tunable via
`filemonitor.fsx.retry.max-attempts` and `filemonitor.fsx.retry.backoff-millis`.

## Profiles

- `local` — H2 in-memory, seeded sample data, 30s scan interval, debug logging
- `dev`   — MySQL, `ddl-auto: validate` (run your own migrations), standard AWS creds
- `sit`   — MySQL, 2 min scan interval, relies on IAM role (no static AWS keys)
- `prod`  — MySQL with tuned HikariCP pool, 5 min scan interval, IAM role, WARN-level logging

Set via `SPRING_PROFILES_ACTIVE` env var or `-Dspring-boot.run.profiles=<name>`.

## Extending

- **New check type**: implement `FileCheckStrategy`, annotate `@Component` — auto-registered
  in `CheckStrategyFactory` via Spring's `List<FileCheckStrategy>` injection.
- **New storage backend**: implement `StorageProvider`, annotate `@Component` — auto-registered
  in `StorageProviderFactory` the same way.
- **Notifications on alert**: `AlertService.raise(...)` currently only persists to
  `ALERT_LOG`. Add an email/Slack dispatch call there, or poll unresolved alerts on a
  separate schedule to decouple detection from notification delivery.
