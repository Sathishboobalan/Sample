package com.health.filemonitor.service;

/**
 * Common contract for all storage watchers.
 * Spring Boot activates exactly ONE implementation based on the active profile:
 *   local  -> LocalFileWatcher
 *   dev    -> S3StagePoller
 *   sit    -> S3StagePoller
 *   prod   -> FSXStageWatcher
 */
public interface StageWatcherPort {
    void start();
    String getStorageType();   // "LOCAL" | "S3" | "FSX"
}
