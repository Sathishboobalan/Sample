package com.health.filemonitor.service;

import com.health.filemonitor.entity.FileAuditEvent;
import com.health.filemonitor.entity.FileRoute;
import com.health.filemonitor.repository.FileAuditEventRepository;
import com.health.filemonitor.repository.FileRouteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Runs on a timer and checks: "did expected files arrive today?"
 * If a file was expected by a certain time and hasn't appeared, write a FILE_MISSING alert.
 * Works identically regardless of which storage mode is active (LOCAL / S3 / FSX).
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class MissingFileScheduler {

    private final FileRouteRepository routeRepository;
    private final FileAuditEventRepository auditRepository;
    private final AuditEventService auditService;

    @Scheduled(fixedDelayString = "${scheduler.check-interval-ms:900000}")
    public void checkMissingFiles() {
        log.debug("Running missing-file check...");

        List<FileRoute> routes = routeRepository.findByActiveTrue().stream()
            .filter(FileRoute::isCheckMissingFile)
            .filter(r -> r.getExpectedTime() != null)
            .toList();

        for (FileRoute route : routes) {
            checkRoute(route);
        }
    }

    private void checkRoute(FileRoute route) {
        LocalTime expected = LocalTime.parse(route.getExpectedTime());
        int grace          = (route.getGraceMinutes() != null) ? route.getGraceMinutes() : 30;
        LocalTime deadline = expected.plusMinutes(grace);

        // Not yet past deadline — nothing to check
        if (LocalTime.now().isBefore(deadline)) return;

        OffsetDateTime startOfDay = OffsetDateTime.now()
            .withHour(0).withMinute(0).withSecond(0).withNano(0);

        boolean arrived = auditRepository.existsByRouteIdAndStageAndOccurredAtAfter(
            route.getRouteId(), "INBOUND", startOfDay);

        if (arrived) return;    // file showed up, all good

        // File is missing — write an alert audit event
        FileAuditEvent alert = FileAuditEvent.builder()
            .correlationId(UUID.randomUUID())
            .clientId(route.getClientId())
            .routeId(route.getRouteId())
            .fileName("(expected: " + route.getFileNamePattern() + ")")
            .stage("INBOUND")
            .eventType("FILE_MISSING")
            .status("FAIL")
            .errorDetail(String.format(
                "Expected by %s + %d min grace = %s, but no file received today",
                expected, grace, deadline))
            .occurredAt(OffsetDateTime.now())
            .build();

        auditService.record(alert);
    }
}
