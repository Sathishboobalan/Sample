package com.health.filemonitor.service;

import com.health.filemonitor.entity.FileAuditEvent;
import com.health.filemonitor.repository.FileAuditEventRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The single place where audit events are written.
 * Every watcher calls record() — nothing else writes audit events directly.
 *
 * Also keeps an in-memory map of fileName -> correlationId so all stages
 * of the same physical file share the same UUID without extra DB queries.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AuditEventService {

    private final FileAuditEventRepository repository;

    // In-memory cache: "routeId::fileName" -> correlationId
    // Lets us link INBOUND, STAGING, PROCESSING, OUTBOUND, ARCHIVE of the same file
    // without hitting the database on every event.
    private final Map<String, UUID> correlationCache = new ConcurrentHashMap<>();

    /**
     * Save one audit event and print a formatted console log line.
     */
    public FileAuditEvent record(FileAuditEvent event) {
        FileAuditEvent saved = repository.save(event);
        printConsoleLog(saved);
        return saved;
    }

    /**
     * Returns (or creates) a stable correlationId for a given file.
     * Called by watchers before building an event so all stages share the same ID.
     */
    public UUID resolveCorrelationId(String routeId, String fileName) {
        String cacheKey = routeId + "::" + fileName;
        return correlationCache.computeIfAbsent(cacheKey, k -> UUID.randomUUID());
    }

    /**
     * Evicts a file from the cache once it is archived — keeps memory lean.
     * Call this when an ARCHIVE event is recorded.
     */
    public void evictCorrelation(String routeId, String fileName) {
        correlationCache.remove(routeId + "::" + fileName);
    }

    public List<FileAuditEvent> getTrail(UUID correlationId) {
        return repository.findByCorrelationIdOrderByOccurredAtAsc(correlationId);
    }

    public List<FileAuditEvent> getRecentEvents(int minutes) {
        OffsetDateTime since = OffsetDateTime.now().minusMinutes(minutes);
        return repository.findRecentEvents(since);
    }

    // ── Console display ───────────────────────────────────────────────────────
    private void printConsoleLog(FileAuditEvent e) {
        String icon = switch (e.getStatus()) {
            case "OK"   -> "✅";
            case "WARN" -> "⚠️ ";
            case "FAIL" -> "❌";
            default     -> "ℹ️ ";
        };

        String sizeInfo = e.getFileSizeBytes() != null
            ? String.format(" [%,d bytes]", e.getFileSizeBytes()) : "";

        String countInfo = (e.getRecordCount() != null && e.getExpectedCount() != null)
            ? String.format(" [records: %d / expected: %d]", e.getRecordCount(), e.getExpectedCount()) : "";

        String errorInfo = e.getErrorDetail() != null
            ? " | ERROR: " + e.getErrorDetail() : "";

        log.info("{} [{}][{}] {} | {} -> {} | {}{}{}{} | corr={}",
            icon,
            e.getStorageMode(),
            e.getClientId(),
            e.getRouteId(),
            e.getStage(),
            e.getEventType(),
            e.getFileName(),
            sizeInfo,
            countInfo,
            errorInfo,
            e.getCorrelationId().toString().substring(0, 8) + "..."
        );
    }
}
