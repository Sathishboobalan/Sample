package com.health.filemonitor.service;

import com.health.filemonitor.entity.FileAuditEvent;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.OffsetDateTime;
import java.util.UUID;

import static java.nio.file.StandardWatchEventKinds.*;

/**
 * Watches FSX (Windows file share) mount paths using Java WatchService.
 * Active only when profile = prod.
 *
 * FSX is mounted on the application server as a regular network drive.
 * Java sees it as a normal filesystem path, so WatchService works fine.
 * Paths in the file_route table look like: /mnt/fsx/ibx/inbound
 */
@Service
@Profile("prod")
@RequiredArgsConstructor
@Slf4j
public class FSXStageWatcher implements StageWatcherPort {

    private final RouteMatcherService matcher;
    private final AuditEventService auditService;

    @Override
    public String getStorageType() { return "FSX"; }

    @PostConstruct
    @Override
    public void start() {
        log.info("╔═══════════════════════════════════════════╗");
        log.info("║  Storage mode : FSX (prod profile)        ║");
        log.info("╚═══════════════════════════════════════════╝");

        try {
            WatchService ws = FileSystems.getDefault().newWatchService();
            int count = 0;

            for (String path : matcher.allActivePaths()) {
                try {
                    Paths.get(path).register(ws, ENTRY_CREATE, ENTRY_DELETE);
                    log.info("  👁  FSX watching: {}", path);
                    count++;
                } catch (IOException e) {
                    log.error("  ✗  Cannot watch FSX path {}: {}", path, e.getMessage());
                }
            }

            if (count == 0) {
                log.warn("No FSX paths could be registered — check FSX mount and file_route table");
                return;
            }

            Thread t = new Thread(() -> watchLoop(ws), "fsx-watcher");
            t.setDaemon(true);
            t.start();
            log.info("FSX watcher running — monitoring {} paths", count);

        } catch (IOException e) {
            log.error("Failed to start FSXStageWatcher: {}", e.getMessage());
        }
    }

    private void watchLoop(WatchService ws) {
        while (true) {
            WatchKey key;
            try {
                key = ws.take();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            String folder = key.watchable().toString();
            for (WatchEvent<?> event : key.pollEvents()) {
                if (event.kind() == OVERFLOW) continue;
                String fileName = ((Path) event.context()).getFileName().toString();
                if (!fileName.startsWith(".") && !fileName.startsWith("~")) {
                    handleEvent(fileName, folder, event.kind());
                }
            }
            key.reset();
        }
    }

    private void handleEvent(String fileName, String folder, WatchEvent.Kind<?> kind) {
        matcher.match(fileName, folder).ifPresentOrElse(
            route -> {
                UUID  correlId  = auditService.resolveCorrelationId(route.getRouteId(), fileName);
                long  size      = readSize(folder, fileName);
                String stage    = matcher.resolveStage(folder, route);
                String evtType  = (kind == ENTRY_CREATE) ? "RECEIVED" : "MOVED_OUT";

                FileAuditEvent event = FileAuditEvent.builder()
                    .correlationId(correlId)
                    .clientId(route.getClientId())
                    .routeId(route.getRouteId())
                    .fileName(fileName)
                    .stage(stage)
                    .eventType(evtType)
                    .status("OK")
                    .fileSizeBytes(size)
                    .sourcePath(folder + "/" + fileName)
                    .storageMode("FSX")
                    .occurredAt(OffsetDateTime.now())
                    .build();

                auditService.record(event);

                if ("ARCHIVE".equals(stage) && kind == ENTRY_CREATE) {
                    auditService.evictCorrelation(route.getRouteId(), fileName);
                }
            },
            () -> log.debug("No route match for {} in {}", fileName, folder)
        );
    }

    private long readSize(String folder, String fileName) {
        try {
            BasicFileAttributes a = Files.readAttributes(
                Paths.get(folder, fileName), BasicFileAttributes.class);
            return a.size();
        } catch (IOException e) {
            return 0L;
        }
    }
}
