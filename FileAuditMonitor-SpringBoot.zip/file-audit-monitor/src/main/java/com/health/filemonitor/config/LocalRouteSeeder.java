package com.health.filemonitor.config;

import com.health.filemonitor.entity.FileRoute;
import com.health.filemonitor.repository.FileRouteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * For the LOCAL profile: reads routes from application-local.yml
 * and seeds them into the H2 database on startup.
 *
 * This means you do not need to run any SQL manually — just configure
 * routes in the YAML and they appear in the DB automatically.
 *
 * For dev/sit/prod: routes are already in the PostgreSQL database
 * (inserted once via the SQL scripts in Section 8 of the previous guides).
 */
@Configuration
@Profile("local")
@RequiredArgsConstructor
@Slf4j
public class LocalRouteSeeder {

    private final FileRouteRepository routeRepository;
    private final LocalWatchProperties properties;

    @Bean
    CommandLineRunner seedRoutes() {
        return args -> {
            if (properties.getRoutes() == null || properties.getRoutes().isEmpty()) {
                log.warn("No routes configured in application-local.yml under local.watch.routes");
                return;
            }

            for (LocalWatchProperties.RouteConfig cfg : properties.getRoutes()) {
                boolean exists = routeRepository.findByRouteId(cfg.getRouteId()).isPresent();
                if (!exists) {
                    FileRoute route = FileRoute.builder()
                        .routeId(cfg.getRouteId())
                        .clientId(cfg.getClientId())
                        .interfaceName(cfg.getInterfaceName())
                        .fileNamePattern(cfg.getFileNamePattern())
                        .inboundPath(cfg.getInboundPath())
                        .stagingPath(cfg.getStagingPath())
                        .outboundPath(cfg.getOutboundPath())
                        .archivePath(cfg.getArchivePath())
                        .expectedTime("08:00")
                        .graceMinutes(30)
                        .checkMissingFile(true)
                        .active(true)
                        .build();
                    routeRepository.save(route);
                    log.info("  ✚  Route seeded: {}", cfg.getRouteId());
                } else {
                    log.info("  ✔  Route already exists: {}", cfg.getRouteId());
                }
            }
            log.info("Route seeding complete — {} routes active",
                routeRepository.findByActiveTrue().size());
        };
    }
}

/**
 * Maps the local.watch section in application-local.yml to a Java object.
 * Spring Boot reads the YAML and populates this class automatically.
 */
@Component
@ConfigurationProperties(prefix = "local.watch")
@lombok.Data
class LocalWatchProperties {

    private String root;
    private List<RouteConfig> routes = new ArrayList<>();

    @lombok.Data
    public static class RouteConfig {
        private String routeId;
        private String clientId;
        private String interfaceName;
        private String fileNamePattern;
        private String inboundPath;
        private String stagingPath;
        private String outboundPath;
        private String archivePath;
    }
}
