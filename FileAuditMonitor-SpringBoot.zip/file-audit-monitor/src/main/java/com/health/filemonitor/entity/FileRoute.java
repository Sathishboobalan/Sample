package com.health.filemonitor.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * One configured file type.
 * Stores the folder paths, expected timing, name pattern, and which checks are on.
 *
 * LOCAL profile: paths are like  /tmp/file-monitor/ibx/inbound
 * DEV/SIT:       paths are like  ibx/inbound/           (S3 prefix)
 * PROD:          paths are like  /mnt/fsx/ibx/inbound   (FSX mount path)
 *
 * The Java code never looks at the format — it passes the path to whichever
 * watcher is active and that watcher knows how to use it.
 */
@Entity
@Table(name = "file_route")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileRoute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String routeId;             // e.g. IBX_APPIN  (unique friendly key)

    @Column(nullable = false, length = 50)
    private String clientId;

    @Column(nullable = false, length = 100)
    private String interfaceName;

    /**
     * File name pattern with placeholders:
     *   {date} = 8 digits (YYYYMMDD)
     *   {time} = 6 digits (HHMMSS)
     * Example: "IBXAPPIN{date}{time}P.txt"
     * At runtime this is converted to a regex for matching.
     */
    @Column(nullable = false, length = 255)
    private String fileNamePattern;

    private String inboundPath;
    private String stagingPath;
    private String outboundPath;
    private String archivePath;

    private String expectedTime;        // "08:00" — when file should normally arrive
    private Integer graceMinutes;       // how many minutes late before alerting

    private Integer expectedRecordCount;

    // Configurable check toggles — set to true to enable, false to skip
    @Builder.Default private boolean checkMissingFile   = true;
    @Builder.Default private boolean checkStuckInStage  = false;
    @Builder.Default private boolean checkRecordCount   = false;

    @Builder.Default private boolean active = true;
}
