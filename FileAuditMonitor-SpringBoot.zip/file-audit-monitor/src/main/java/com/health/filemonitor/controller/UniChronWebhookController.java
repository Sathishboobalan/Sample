package com.health.filemonitor.controller;

import com.health.filemonitor.entity.FileAuditEvent;
import com.health.filemonitor.entity.FileRoute;
import com.health.filemonitor.repository.FileRouteRepository;
import com.health.filemonitor.service.AuditEventService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Receives POST callbacks from UniChron when a processing job starts, completes, or fails.
 * Works identically regardless of storage mode (LOCAL / S3 / FSX).
 *
 * Test with curl:
 *   curl -X POST http://localhost:8080/api/job-event \
 *        -H "Content-Type: application/json" \
 *        -d '{"routeId":"IBX_APPIN","jobId":"JOB-001","fileName":"IBXAPPIN20260629080000P.txt","phase":"STARTED"}'
 */
@RestController
@RequestMapping("/api/job-event")
@RequiredArgsConstructor
@Slf4j
public class UniChronWebhookController {

    private final FileRouteRepository routeRepository;
    private final AuditEventService auditService;

    @PostMapping
    public ResponseEntity<String> receiveJobEvent(@RequestBody JobEventRequest req) {
        FileRoute route = routeRepository.findByRouteId(req.getRouteId()).orElse(null);
        if (route == null) {
            log.warn("Job event received for unknown routeId: {}", req.getRouteId());
            return ResponseEntity.ok("unknown route — ignored");
        }

        UUID correlId = auditService.resolveCorrelationId(route.getRouteId(), req.getFileName());

        String eventType = switch (req.getPhase()) {
            case "STARTED"   -> "PROCESSING_STARTED";
            case "COMPLETED" -> "PROCESSING_COMPLETED";
            case "FAILED"    -> "PROCESSING_FAILED";
            default          -> "PROCESSING_" + req.getPhase();
        };

        String status = "FAILED".equals(req.getPhase()) ? "FAIL" : "OK";

        auditService.record(FileAuditEvent.builder()
            .correlationId(correlId)
            .clientId(route.getClientId())
            .routeId(route.getRouteId())
            .fileName(req.getFileName())
            .stage("PROCESSING")
            .eventType(eventType)
            .status(status)
            .jobId(req.getJobId())
            .recordCount(req.getOutputRecordCount())
            .expectedCount(route.getExpectedRecordCount())
            .errorDetail(req.getErrorMessage())
            .occurredAt(OffsetDateTime.now())
            .build());

        // Record count mismatch check (if enabled for this route)
        if ("COMPLETED".equals(req.getPhase())
                && route.isCheckRecordCount()
                && req.getOutputRecordCount() != null
                && route.getExpectedRecordCount() != null
                && !req.getOutputRecordCount().equals(route.getExpectedRecordCount())) {

            auditService.record(FileAuditEvent.builder()
                .correlationId(correlId)
                .clientId(route.getClientId())
                .routeId(route.getRouteId())
                .fileName(req.getFileName())
                .stage("PROCESSING")
                .eventType("RECORD_MISMATCH")
                .status("WARN")
                .recordCount(req.getOutputRecordCount())
                .expectedCount(route.getExpectedRecordCount())
                .occurredAt(OffsetDateTime.now())
                .build());
        }

        return ResponseEntity.ok("recorded");
    }

    /** Shape of the JSON that UniChron (or your curl test) sends. */
    @Data
    public static class JobEventRequest {
        private String routeId;
        private String jobId;
        private String fileName;
        private String phase;               // STARTED | COMPLETED | FAILED
        private Integer outputRecordCount;
        private String errorMessage;
    }
}
