package com.health.filemonitor.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * One row in the audit trail.
 * Every time a file appears, moves, or triggers a check — one row is written here.
 * All rows for ONE physical file share the same correlationId (a UUID).
 * Querying by correlationId gives you the full lifecycle of that file.
 */
@Entity
@Table(name = "file_audit_event", indexes = {
    @Index(name = "idx_correlation",  columnList = "correlationId"),
    @Index(name = "idx_route_stage",  columnList = "routeId, stage, occurredAt DESC"),
    @Index(name = "idx_client_time",  columnList = "clientId, occurredAt DESC")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileAuditEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private UUID correlationId;         // ties all stages of one file together

    @Column(nullable = false, length = 50)
    private String clientId;            // IBX | AMERIBEN | CLOVER | AZBLUE | HIGHMARK

    @Column(nullable = false, length = 100)
    private String routeId;             // IBX_APPIN | CLOVER_CMS | ...

    @Column(nullable = false)
    private String fileName;            // actual file name

    @Column(nullable = false, length = 30)
    private String stage;               // INBOUND | STAGING | PROCESSING | OUTBOUND | ARCHIVE

    @Column(nullable = false, length = 40)
    private String eventType;           // RECEIVED | MOVED_OUT | PROCESSING_STARTED |
                                        // PROCESSING_COMPLETED | PROCESSING_FAILED |
                                        // FILE_MISSING | STUCK_IN_STAGE | RECORD_MISMATCH

    @Column(nullable = false, length = 10)
    private String status;              // OK | WARN | FAIL

    private Long fileSizeBytes;
    private Integer recordCount;
    private Integer expectedCount;
    private String jobId;               // UniChron job reference
    private String sourcePath;          // full path or S3 key where this event happened

    @Column(length = 10)
    private String storageMode;         // LOCAL | S3 | FSX — which watcher detected this

    @Column(columnDefinition = "TEXT")
    private String errorDetail;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private OffsetDateTime occurredAt;
}
