package com.health.filemonitor.service;

import com.health.filemonitor.entity.FileRoute;
import com.health.filemonitor.repository.FileRouteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Shared logic for matching a file name + path to a configured FileRoute.
 * Used by LocalFileWatcher, S3StagePoller, and FSXStageWatcher alike.
 * Centralised here so pattern matching is never duplicated.
 */
@Service
@RequiredArgsConstructor
public class RouteMatcherService {

    private final FileRouteRepository routeRepository;

    /**
     * Finds the route whose path (for the given stage) matches folderPath
     * AND whose fileNamePattern matches fileName.
     *
     * @param fileName   the bare file name, e.g. "IBXAPPIN20260629080000P.txt"
     * @param folderPath the folder or S3 prefix where the file was detected
     * @return the matching FileRoute, or empty if none matches
     */
    public Optional<FileRoute> match(String fileName, String folderPath) {
        return routeRepository.findByActiveTrue().stream()
            .filter(r -> pathBelongsToRoute(folderPath, r))
            .filter(r -> matchesPattern(fileName, r.getFileNamePattern()))
            .findFirst();
    }

    /**
     * Given a folder path and a route, determines which stage that folder represents.
     */
    public String resolveStage(String folderPath, FileRoute route) {
        if (equals(folderPath, route.getInboundPath()))  return "INBOUND";
        if (equals(folderPath, route.getStagingPath()))  return "STAGING";
        if (equals(folderPath, route.getOutboundPath())) return "OUTBOUND";
        if (equals(folderPath, route.getArchivePath()))  return "ARCHIVE";
        return "UNKNOWN";
    }

    /** Returns all paths registered across all active routes — used to know what to watch. */
    public List<String> allActivePaths() {
        return routeRepository.findByActiveTrue().stream()
            .flatMap(r -> List.of(
                r.getInboundPath(), r.getStagingPath(),
                r.getOutboundPath(), r.getArchivePath()
            ).stream())
            .filter(p -> p != null && !p.isBlank())
            .distinct()
            .toList();
    }

    // ── private helpers ───────────────────────────────────────────────────────

    private boolean pathBelongsToRoute(String path, FileRoute route) {
        return equals(path, route.getInboundPath())
            || equals(path, route.getStagingPath())
            || equals(path, route.getOutboundPath())
            || equals(path, route.getArchivePath());
    }

    /**
     * Converts a simple pattern with placeholders to a Java regex and tests the file name.
     * Supported placeholders:
     *   {date} → \d{8}   (8-digit date, e.g. 20260629)
     *   {time} → \d{6}   (6-digit time, e.g. 143000)
     *   {any}  → .*      (matches anything)
     */
    public boolean matchesPattern(String fileName, String pattern) {
        if (pattern == null || pattern.isBlank()) return false;
        String regex = pattern
            .replace(".", "\\.")        // escape literal dots first
            .replace("{date}", "\\d{8}")
            .replace("{time}", "\\d{6}")
            .replace("{any}",  ".*");
        return fileName.matches(regex);
    }

    private boolean equals(String a, String b) {
        return a != null && b != null && a.equals(b);
    }
}
