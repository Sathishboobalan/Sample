package com.health.filemonitor.repository;

import com.health.filemonitor.entity.FileAuditEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

public interface FileAuditEventRepository extends JpaRepository<FileAuditEvent, Long> {

    // Full lifecycle of one file — ordered oldest-first for timeline display
    List<FileAuditEvent> findByCorrelationIdOrderByOccurredAtAsc(UUID correlationId);

    // All events for a client — for dashboard view
    List<FileAuditEvent> findByClientIdOrderByOccurredAtDesc(String clientId);

    // Check if a file already arrived for a route today (used by missing-file scheduler)
    boolean existsByRouteIdAndStageAndOccurredAtAfter(
            String routeId, String stage, OffsetDateTime after);

    // Recent events across all clients — for the summary API
    @Query("""
        SELECT e FROM FileAuditEvent e
        WHERE e.occurredAt >= :since
        ORDER BY e.occurredAt DESC
        """)
    List<FileAuditEvent> findRecentEvents(@Param("since") OffsetDateTime since);
}
