package com.health.filemonitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling   // required for @Scheduled methods in MissingFileScheduler to fire
public class FileMonitorApplication {
    public static void main(String[] args) {
        SpringApplication.run(FileMonitorApplication.class, args);
    }
}
