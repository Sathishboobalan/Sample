package com.health.filemonitor.repository;

import com.health.filemonitor.entity.FileRoute;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FileRouteRepository extends JpaRepository<FileRoute, Long> {
    List<FileRoute> findByActiveTrue();
    Optional<FileRoute> findByRouteId(String routeId);
    List<FileRoute> findByClientIdAndActiveTrue(String clientId);
}
