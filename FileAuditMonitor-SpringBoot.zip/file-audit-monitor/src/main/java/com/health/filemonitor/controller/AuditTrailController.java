package com.health.filemonitor.controller;

import com.health.filemonitor.entity.FileAuditEvent;
import com.health.filemonitor.entity.FileRoute;
import com.health.filemonitor.repository.FileRouteRepository;
import com.health.filemonitor.service.AuditEventService;
import com.health.filemonitor.service.StageWatcherPort;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * REST endpoints for:
 *   - Checking which storage mode is active
 *   - Viewing recent audit events
 *   - Viewing the full trail for one file
 *   - Viewing configured routes
 *
 * Use these in Postman or a browser to see what the system is doing.
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AuditTrailController {

    private final AuditEventService auditService;
    private final FileRouteRepository routeRepository;
    private final StageWatcherPort watcher;    // Spring injects whichever is active

    /**
     * GET /api/status
     * Shows which storage mode and profile are running.
     * First URL to check when the app starts.
     */
    @GetMapping("/status")
    public Map<String, String> status() {
        return Map.of(
            "storageMode",   watcher.getStorageType(),
            "activeProfile", System.getProperty("spring.profiles.active",
                             System.getenv().getOrDefault("SPRING_PROFILES_ACTIVE", "local")),
            "status",        "UP"
        );
    }

    /**
     * GET /api/events?minutes=60
     * Recent audit events (default last 60 minutes).
     * Useful for watching events roll in as you drop test files.
     */
    @GetMapping("/events")
    public List<FileAuditEvent> recentEvents(
            @RequestParam(defaultValue = "60") int minutes) {
        return auditService.getRecentEvents(minutes);
    }

    /**
     * GET /api/events/trail/{correlationId}
     * Full lifecycle of one specific file — all stages in time order.
     */
    @GetMapping("/events/trail/{correlationId}")
    public ResponseEntity<List<FileAuditEvent>> trail(@PathVariable UUID correlationId) {
        List<FileAuditEvent> events = auditService.getTrail(correlationId);
        return events.isEmpty()
            ? ResponseEntity.notFound().build()
            : ResponseEntity.ok(events);
    }

    /**
     * GET /api/routes
     * All configured file routes — useful to verify seeding worked.
     */
    @GetMapping("/routes")
    public List<FileRoute> routes() {
        return routeRepository.findByActiveTrue();
    }
}
