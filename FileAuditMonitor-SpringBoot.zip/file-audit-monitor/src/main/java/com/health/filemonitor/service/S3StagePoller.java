package com.health.filemonitor.service;

import com.health.filemonitor.entity.FileAuditEvent;
import com.health.filemonitor.entity.FileRoute;
import com.health.filemonitor.repository.FileRouteRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.time.OffsetDateTime;
import java.util.*;

/**
 * Polls S3 prefixes for new/removed files.
 * Active only when profile = dev or sit.
 *
 * Because S3 is object storage (not a filesystem), Java WatchService cannot be used.
 * Instead, we poll S3 on a fixed interval, compare keys to what we saw last time,
 * and emit audit events for anything that changed.
 *
 * Paths in file_route look like: ibx/inbound/  (no leading slash, trailing slash required)
 */
@Service
@Profile({"dev", "sit"})
@RequiredArgsConstructor
@Slf4j
public class S3StagePoller implements StageWatcherPort {

    private final S3Client s3Client;
    private final FileRouteRepository routeRepository;
    private final RouteMatcherService matcher;
    private final AuditEventService auditService;

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    // Snapshot of what keys existed at each prefix during the last poll
    private final Map<String, Set<String>> lastKnownKeys = new HashMap<>();

    // All prefix+route+stage combinations to poll
    private record PrefixConfig(String prefix, FileRoute route, String stage) {}
    private final List<PrefixConfig> pollTargets = new ArrayList<>();

    @Override
    public String getStorageType() { return "S3"; }

    @PostConstruct
    @Override
    public void start() {
        log.info("╔══════════════════════════════════════════════════╗");
        log.info("║  Storage mode : S3 (dev/sit profile)             ║");
        log.info("║  Bucket       : {}  ║", padRight(bucketName, 28));
        log.info("╚══════════════════════════════════════════════════╝");

        for (FileRoute route : routeRepository.findByActiveTrue()) {
            addTarget(route.getInboundPath(),  route, "INBOUND");
            addTarget(route.getStagingPath(),  route, "STAGING");
            addTarget(route.getOutboundPath(), route, "OUTBOUND");
            addTarget(route.getArchivePath(),  route, "ARCHIVE");
        }
        log.info("S3 poller watching {} prefixes across {} routes",
            pollTargets.size(), routeRepository.findByActiveTrue().size());
        pollTargets.forEach(t -> log.info("  👁  s3://{}/{}", bucketName, t.prefix()));
    }

    private void addTarget(String path, FileRoute route, String stage) {
        if (path != null && !path.isBlank()) {
            pollTargets.add(new PrefixConfig(path, route, stage));
            lastKnownKeys.put(path, new HashSet<>());
        }
    }

    /** Runs every N milliseconds (configured in application.yml poller.interval-ms) */
    @Scheduled(fixedDelayString = "${poller.interval-ms:30000}")
    public void pollAllPrefixes() {
        for (PrefixConfig target : pollTargets) {
            try {
                poll(target);
            } catch (Exception e) {
                log.error("Error polling s3://{}/{}: {}", bucketName, target.prefix(), e.getMessage());
            }
        }
    }

    private void poll(PrefixConfig target) {
        Set<String> current  = listKeys(target.prefix());
        Set<String> previous = lastKnownKeys.getOrDefault(target.prefix(), Collections.emptySet());

        // New = in current but not in previous
        Set<String> added = new HashSet<>(current);
        added.removeAll(previous);

        // Removed = in previous but not in current
        Set<String> removed = new HashSet<>(previous);
        removed.removeAll(current);

        added.forEach(key   -> onFileAdded(key, target));
        removed.forEach(key -> onFileRemoved(key, target));

        lastKnownKeys.put(target.prefix(), current);
    }

    private Set<String> listKeys(String prefix) {
        Set<String> keys = new HashSet<>();
        try {
            s3Client.listObjectsV2Paginator(
                ListObjectsV2Request.builder().bucket(bucketName).prefix(prefix).build()
            ).forEach(page -> page.contents().forEach(obj -> {
                // skip "folder" placeholder objects (end with /)
                if (!obj.key().endsWith("/")) {
                    keys.add(obj.key());
                }
            }));
        } catch (S3Exception e) {
            log.error("S3 list error for prefix {}: {}", prefix, e.awsErrorDetails().errorMessage());
        }
        return keys;
    }

    private void onFileAdded(String s3Key, PrefixConfig target) {
        String fileName = extractFileName(s3Key);
        if (!matcher.matchesPattern(fileName, target.route().getFileNamePattern())) return;

        long size = headObjectSize(s3Key);
        UUID correlId = auditService.resolveCorrelationId(target.route().getRouteId(), fileName);

        auditService.record(FileAuditEvent.builder()
            .correlationId(correlId)
            .clientId(target.route().getClientId())
            .routeId(target.route().getRouteId())
            .fileName(fileName)
            .stage(target.stage())
            .eventType("RECEIVED")
            .status("OK")
            .fileSizeBytes(size)
            .sourcePath("s3://" + bucketName + "/" + s3Key)
            .storageMode("S3")
            .occurredAt(OffsetDateTime.now())
            .build());

        if ("ARCHIVE".equals(target.stage())) {
            auditService.evictCorrelation(target.route().getRouteId(), fileName);
        }
    }

    private void onFileRemoved(String s3Key, PrefixConfig target) {
        String fileName = extractFileName(s3Key);
        if (!matcher.matchesPattern(fileName, target.route().getFileNamePattern())) return;

        UUID correlId = auditService.resolveCorrelationId(target.route().getRouteId(), fileName);

        auditService.record(FileAuditEvent.builder()
            .correlationId(correlId)
            .clientId(target.route().getClientId())
            .routeId(target.route().getRouteId())
            .fileName(fileName)
            .stage(target.stage())
            .eventType("MOVED_OUT")
            .status("OK")
            .sourcePath("s3://" + bucketName + "/" + s3Key)
            .storageMode("S3")
            .occurredAt(OffsetDateTime.now())
            .build());
    }

    private long headObjectSize(String key) {
        try {
            return s3Client.headObject(
                HeadObjectRequest.builder().bucket(bucketName).key(key).build()
            ).contentLength();
        } catch (Exception e) {
            return 0L;
        }
    }

    private String extractFileName(String s3Key) {
        int i = s3Key.lastIndexOf('/');
        return (i >= 0) ? s3Key.substring(i + 1) : s3Key;
    }

    private String padRight(String s, int n) {
        return String.format("%-" + n + "s", s);
    }
}
