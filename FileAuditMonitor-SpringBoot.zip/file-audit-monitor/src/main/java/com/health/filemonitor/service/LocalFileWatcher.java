package com.health.filemonitor.service;

import com.health.filemonitor.entity.FileAuditEvent;
import com.health.filemonitor.entity.FileRoute;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.OffsetDateTime;
import java.util.UUID;

import static java.nio.file.StandardWatchEventKinds.*;

/**
 * Watches local filesystem folders on your laptop.
 * Active only when profile = local.
 *
 * HOW TO TEST:
 *   1. Run the app with profile=local
 *   2. The app auto-creates all folders listed in application-local.yml
 *   3. Drop any file into /tmp/file-monitor/ibx/inbound
 *   4. Watch the console — you will see an audit log line within 1 second
 */
@Service
@Profile("local")
@RequiredArgsConstructor
@Slf4j
public class LocalFileWatcher implements StageWatcherPort {

    private final RouteMatcherService matcher;
    private final AuditEventService auditService;

    @Override
    public String getStorageType() { return "LOCAL"; }

    @PostConstruct
    @Override
    public void start() {
        log.info("╔══════════════════════════════════════════════╗");
        log.info("║  Storage mode : LOCAL (local profile)        ║");
        log.info("║  Drop files into the watched folders to test ║");
        log.info("╚══════════════════════════════════════════════╝");

        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            boolean anyRegistered = false;

            for (String path : matcher.allActivePaths()) {
                if (registerPath(watchService, path)) {
                    anyRegistered = true;
                }
            }

            if (!anyRegistered) {
                log.warn("No folders registered — check your local.watch.routes config " +
                         "and make sure the folders exist (or app will create them if you " +
                         "use the DataInitializer below)");
                return;
            }

            // Run watch loop on a background daemon thread
            Thread t = new Thread(() -> watchLoop(watchService), "local-watcher");
            t.setDaemon(true);
            t.start();

        } catch (IOException e) {
            log.error("Failed to start LocalFileWatcher: {}", e.getMessage());
        }
    }

    private boolean registerPath(WatchService ws, String path) {
        Path folder = Paths.get(path);
        try {
            // Create the folder if it does not exist yet — convenience for local dev
            Files.createDirectories(folder);
            folder.register(ws, ENTRY_CREATE, ENTRY_DELETE);
            log.info("  👁  Watching: {}", path);
            return true;
        } catch (IOException e) {
            log.error("  ✗  Cannot watch {}: {}", path, e.getMessage());
            return false;
        }
    }

    private void watchLoop(WatchService ws) {
        log.info("Local file watcher running — waiting for files...");
        while (true) {
            WatchKey key;
            try {
                key = ws.take();    // blocks until something happens
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }

            String folder = key.watchable().toString();
            for (WatchEvent<?> event : key.pollEvents()) {
                if (event.kind() == OVERFLOW) continue;
                String fileName = ((Path) event.context()).getFileName().toString();
                handleEvent(fileName, folder, event.kind());
            }
            key.reset();
        }
    }

    private void handleEvent(String fileName, String folder, WatchEvent.Kind<?> kind) {
        // Skip hidden files and temp files (e.g. .DS_Store, ~lockfile)
        if (fileName.startsWith(".") || fileName.startsWith("~")) return;

        matcher.match(fileName, folder).ifPresentOrElse(
            route -> {
                String stage        = matcher.resolveStage(folder, route);
                String eventType    = (kind == ENTRY_CREATE) ? "RECEIVED" : "MOVED_OUT";
                UUID   correlId     = auditService.resolveCorrelationId(route.getRouteId(), fileName);
                long   size         = readSize(folder, fileName);

                FileAuditEvent event = FileAuditEvent.builder()
                    .correlationId(correlId)
                    .clientId(route.getClientId())
                    .routeId(route.getRouteId())
                    .fileName(fileName)
                    .stage(stage)
                    .eventType(eventType)
                    .status("OK")
                    .fileSizeBytes(size)
                    .sourcePath(folder + "/" + fileName)
                    .storageMode("LOCAL")
                    .occurredAt(OffsetDateTime.now())
                    .build();

                auditService.record(event);

                // When file reaches ARCHIVE stage, free the correlationId from cache
                if ("ARCHIVE".equals(stage) && kind == ENTRY_CREATE) {
                    auditService.evictCorrelation(route.getRouteId(), fileName);
                }
            },
            () -> log.debug("  ↷  Ignored (no route match): {} in {}", fileName, folder)
        );
    }

    private long readSize(String folder, String fileName) {
        try {
            BasicFileAttributes attrs = Files.readAttributes(
                Paths.get(folder, fileName), BasicFileAttributes.class);
            return attrs.size();
        } catch (IOException e) {
            return 0L;
        }
    }
}
