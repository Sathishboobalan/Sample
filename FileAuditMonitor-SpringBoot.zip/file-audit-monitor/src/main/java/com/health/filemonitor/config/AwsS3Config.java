package com.health.filemonitor.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import software.amazon.awssdk.auth.credentials.*;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

/**
 * Creates the S3Client bean ONLY for dev and sit profiles.
 * On local and prod this entire class is skipped — S3Client is never instantiated.
 * This prevents startup failures on machines with no AWS credentials.
 */
@Configuration
@Profile({"dev", "sit"})
@Slf4j
public class AwsS3Config {

    @Value("${aws.region}")
    private String region;

    @Value("${aws.credentials.access-key:}")
    private String accessKey;

    @Value("${aws.credentials.secret-key:}")
    private String secretKey;

    @Bean
    public S3Client s3Client() {
        S3Client.Builder builder = S3Client.builder().region(Region.of(region));

        if (accessKey != null && !accessKey.isBlank()
                && secretKey != null && !secretKey.isBlank()) {
            // Explicit credentials — used for local-to-S3 testing or CI pipelines
            log.info("[AWS] Using explicit credentials from config");
            builder.credentialsProvider(
                StaticCredentialsProvider.create(
                    AwsBasicCredentials.create(accessKey, secretKey)));
        } else {
            // Auto-discover credentials:
            //   1. Env vars AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY
            //   2. ~/.aws/credentials (local machine)
            //   3. IAM Role on EC2/ECS instance (best for deployed environments)
            log.info("[AWS] Using default credentials provider (IAM Role / env vars / ~/.aws)");
            builder.credentialsProvider(DefaultCredentialsProvider.create());
        }

        return builder.build();
    }
}
